package com.zeroai;

import net.minecraftforge.common.ForgeConfigSpec;
import java.util.*;

public final class ZeroConfig {
    public enum Provider { OLLAMA, GROQ, OPENAI, GEMINI }
    public enum TtsMode { SYSTEM, OPENAI }

    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.EnumValue<Provider> PROVIDER;
    public static final ForgeConfigSpec.EnumValue<TtsMode> TTS_MODE;
    public static final ForgeConfigSpec.ConfigValue<String> OLLAMA_URL, OLLAMA_MODEL, GROQ_MODEL, GROQ_KEY,
            OPENAI_MODEL, OPENAI_KEY, GEMINI_MODEL, GEMINI_KEY, LANGUAGE, STT_LANG, STT_MODEL_GROQ,
            STT_MODEL_OPENAI, TTS_VOICE, TTS_MODEL, ALLOWED_COMMANDS;
    public static final ForgeConfigSpec.BooleanValue TTS_ENABLED, ALLOW_COMMANDS, MUSIC_ENABLED;
    public static final ForgeConfigSpec.IntValue MIN_MOOD_FOR_COMMANDS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        PROVIDER = b.comment("OLLAMA, GROQ, OPENAI atau GEMINI").defineEnum("provider", Provider.GROQ);
        OLLAMA_URL = b.define("ollamaUrl", "http://localhost:11434");
        OLLAMA_MODEL = b.define("ollamaModel", "llama3.1");
        GROQ_MODEL = b.define("groqModel", "llama-3.3-70b-versatile");
        GROQ_KEY = b.define("groqKey", "");
        OPENAI_MODEL = b.define("openaiModel", "gpt-4o-mini");
        OPENAI_KEY = b.define("openaiKey", "");
        GEMINI_MODEL = b.define("geminiModel", "gemini-2.5-flash");
        GEMINI_KEY = b.define("geminiKey", "");
        LANGUAGE = b.define("language", "Bahasa Indonesia");
        STT_LANG = b.comment("Kode bahasa suara (id, en, ...). Kosong = otomatis").define("sttLanguage", "id");
        STT_MODEL_GROQ = b.define("sttModelGroq", "whisper-large-v3-turbo");
        STT_MODEL_OPENAI = b.define("sttModelOpenai", "whisper-1");
        TTS_ENABLED = b.define("ttsEnabled", true);
        TTS_MODE = b.defineEnum("ttsMode", TtsMode.SYSTEM);
        TTS_MODEL = b.define("openaiTtsModel", "tts-1");
        TTS_VOICE = b.define("openaiTtsVoice", "alloy");
        ALLOW_COMMANDS = b.define("allowCommands", true);
        ALLOWED_COMMANDS = b.comment("Daftar perintah yang boleh dijalankan AI, pisah koma")
                .define("allowedCommands", "effect,give,fill,setblock,tp,teleport,locate,time,weather");
        MIN_MOOD_FOR_COMMANDS = b.defineInRange("minMoodForCommands", 20, 0, 100);
        MUSIC_ENABLED = b.define("musicEnabled", true);
        SPEC = b.build();
    }

    public static String modelFor(Provider p) {
        return switch (p) {
            case OLLAMA -> OLLAMA_MODEL.get();
            case GROQ -> GROQ_MODEL.get();
            case OPENAI -> OPENAI_MODEL.get();
            case GEMINI -> GEMINI_MODEL.get();
        };
    }
    public static void setModel(Provider p, String v) {
        switch (p) {
            case OLLAMA -> OLLAMA_MODEL.set(v);
            case GROQ -> GROQ_MODEL.set(v);
            case OPENAI -> OPENAI_MODEL.set(v);
            case GEMINI -> GEMINI_MODEL.set(v);
        }
    }
    public static String keyFor(Provider p) {
        return switch (p) {
            case OLLAMA -> "";
            case GROQ -> GROQ_KEY.get();
            case OPENAI -> OPENAI_KEY.get();
            case GEMINI -> GEMINI_KEY.get();
        };
    }
    public static void setKey(Provider p, String v) {
        switch (p) {
            case GROQ -> GROQ_KEY.set(v);
            case OPENAI -> OPENAI_KEY.set(v);
            case GEMINI -> GEMINI_KEY.set(v);
            default -> {}
        }
    }
    public static Set<String> allowed() {
        Set<String> s = new HashSet<>();
        for (String c : ALLOWED_COMMANDS.get().split(",")) if (!c.isBlank()) s.add(c.trim().toLowerCase(Locale.ROOT));
        return s;
    }
    public static void save() { try { PROVIDER.save(); } catch (Exception ignored) {} }
}
