package com.zeroai;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.zeroai.entity.ZeroEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Comparator;
import java.util.List;

@Mod.EventBusSubscriber(modid = ZeroMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ZeroCommands {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("zeroai")
                .then(Commands.literal("spawn").executes(c -> spawn(c.getSource())))
                .then(Commands.literal("backrooms").requires(x -> x.hasPermission(2)).executes(c -> {
                    var pl = c.getSource().getPlayer();
                    return pl != null && BackroomsManager.send(pl, null) ? 1 : 0;
                }))
                .then(Commands.literal("domain")
                        .then(Commands.literal("paradise").executes(c -> domain(c.getSource(), "paradise", ZeroCommonConfig.PARADISE_SECONDS.get())))
                        .then(Commands.literal("inferno").requires(x -> x.hasPermission(2)).executes(c -> domain(c.getSource(), "inferno", ZeroCommonConfig.WRATH_SECONDS.get())))
                        .then(Commands.literal("end").executes(c -> DomainManager.end(c.getSource().getLevel(), BlockPos.containing(c.getSource().getPosition())) ? 1 : 0)))
                .then(dim())
                .then(Commands.literal("mood")
                        .then(Commands.literal("add").then(Commands.argument("amount", IntegerArgumentType.integer(-50, 50))
                                .executes(c -> mood(c, IntegerArgumentType.getInteger(c, "amount"), false))))
                        .then(Commands.literal("set").requires(s -> s.hasPermission(2))
                                .then(Commands.argument("value", IntegerArgumentType.integer(0, 100))
                                        .executes(c -> mood(c, IntegerArgumentType.getInteger(c, "value"), true))))));
    }

    private static int domain(CommandSourceStack src, String type, int secs) {
        boolean ok = DomainManager.open(src.getLevel(), BlockPos.containing(src.getPosition()), type, secs);
        if (!ok) src.sendFailure(Component.literal("Sudah ada wilayah Zero aktif di dekat sini."));
        return ok ? 1 : 0;
    }

    private static LiteralArgumentBuilder<CommandSourceStack> dim() {
        LiteralArgumentBuilder<CommandSourceStack> d = Commands.literal("dim");
        d.then(Commands.literal("return").executes(c -> { var p = c.getSource().getPlayer(); return p != null && DimManager.back(p) ? 1 : 0; }));
        d.then(Commands.literal("paradise").executes(c -> { var p = c.getSource().getPlayer(); return p != null && DimManager.send(p, "paradise", ZeroCommonConfig.PARADISE_SECONDS.get()) ? 1 : 0; }));
        d.then(Commands.literal("inferno").requires(x -> x.hasPermission(2)).executes(c -> { var p = c.getSource().getPlayer(); return p != null && DimManager.send(p, "inferno", ZeroCommonConfig.WRATH_SECONDS.get()) ? 1 : 0; }));
        for (int i = 1; i <= 3; i++) {
            final String n = "realm_" + i;
            d.then(Commands.literal(n).executes(c -> { var p = c.getSource().getPlayer(); return p != null && DimManager.send(p, n, ZeroCommonConfig.REALM_SECONDS.get()) ? 1 : 0; }));
        }
        return d;
    }

    private static int spawn(CommandSourceStack src) {
        ServerLevel lvl = src.getLevel();
        ZeroEntity z = ZeroMod.ZERO.get().create(lvl);
        if (z == null) return 0;
        Vec3 p = src.getPosition();
        z.moveTo(p.x, p.y, p.z, 0f, 0f);
        lvl.addFreshEntity(z);
        src.sendSuccess(() -> Component.literal("Zero AI muncul! BEEP!"), false);
        return 1;
    }

    private static int mood(CommandContext<CommandSourceStack> c, int v, boolean set) {
        CommandSourceStack src = c.getSource();
        Vec3 p = src.getPosition();
        List<ZeroEntity> l = src.getLevel().getEntitiesOfClass(ZeroEntity.class, new AABB(p, p).inflate(64));
        if (l.isEmpty()) return 0;
        l.sort(Comparator.comparingDouble(en -> en.distanceToSqr(p)));
        ZeroEntity z = l.get(0);
        if (set) z.setMood(v); else z.addMood(v);
        return 1;
    }
}
