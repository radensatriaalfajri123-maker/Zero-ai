package com.zeroai;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.zeroai.entity.ZeroEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Comparator;
import java.util.List;

@Mod.EventBusSubscriber(modid = ZeroMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ZeroCommands {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("zeroai")
                .then(Commands.literal("spawn").executes(c -> spawn(c.getSource())))
                .then(Commands.literal("mood")
                        .then(Commands.literal("add").then(Commands.argument("amount", IntegerArgumentType.integer(-50, 50))
                                .executes(c -> mood(c, IntegerArgumentType.getInteger(c, "amount"), false))))
                        .then(Commands.literal("set").requires(s -> s.hasPermission(2))
                                .then(Commands.argument("value", IntegerArgumentType.integer(0, 100))
                                        .executes(c -> mood(c, IntegerArgumentType.getInteger(c, "value"), true)))))));
    }

    private static int spawn(CommandSourceStack src) {
        ServerLevel lvl = src.getLevel();
        ZeroEntity z = ZeroMod.ZERO.get().create(lvl);
        if (z == null) return 0;
        Vec3 p = src.getPosition();
        z.moveTo(p.x, p.y, p.z, 0f, 0f);
        lvl.addFreshEntity(z);
        src.sendSuccess(() -> Component.literal("Zero AI muncul! BEEP!"), false);
        return 1;
    }

    private static int mood(CommandContext<CommandSourceStack> c, int v, boolean set) {
        CommandSourceStack src = c.getSource();
        Vec3 p = src.getPosition();
        List<ZeroEntity> l = src.getLevel().getEntitiesOfClass(ZeroEntity.class, new AABB(p, p).inflate(64));
        if (l.isEmpty()) return 0;
        l.sort(Comparator.comparingDouble(en -> en.distanceToSqr(p)));
        ZeroEntity z = l.get(0);
        if (set) z.setMood(v); else z.addMood(v);
        return 1;
    }
}
