package com.zeroai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** Kunjungan ke dimensi buatan Zero: paradise (senang), inferno (marah), realm_1..3 (dirancang AI). */
public final class DimManager {
    static final class Visit { ResourceKey<Level> retDim, dim; Vec3 retPos; float yaw; int left; String name; }
    private static final Map<UUID, Visit> V = new HashMap<>();

    public static ResourceKey<Level> key(String n) { return ResourceKey.create(Registries.DIMENSION, ResourceLocation.fromNamespaceAndPath(ZeroMod.MODID, n)); }
    public static boolean isVisiting(UUID id) { return V.containsKey(id); }
    static Visit take(UUID id) { return V.remove(id); }

    private static void run(MinecraftServer s, String cmd) {
        s.getCommands().performPrefixedCommand(s.createCommandSourceStack().withSuppressedOutput(), cmd);
    }

    public static boolean send(ServerPlayer p, String name, int seconds) {
        MinecraftServer s = p.getServer();
        if (s == null || BackroomsManager.isIn(p.getUUID())) return false;
        ServerLevel lvl = s.getLevel(key(name));
        if (lvl == null) {
            p.sendSystemMessage(Component.literal("§c[Zero AI] Dimensi '" + name + "' belum aktif. Muat ulang world (datapack mod harus terbaca)."));
            return false;
        }
        if (name.equals("paradise") && !DimGen.paradiseReady(lvl)) DimGen.paradise(lvl);
        if (name.equals("inferno") && !DimGen.infernoReady(lvl)) DimGen.inferno(lvl);
        Visit v = V.get(p.getUUID());
        if (v == null) { v = new Visit(); v.retDim = p.level().dimension(); v.retPos = p.position(); v.yaw = p.getYRot(); V.put(p.getUUID(), v); }
        v.dim = lvl.dimension(); v.left = seconds * 20; v.name = name;
        p.fallDistance = 0;
        p.teleportTo(lvl, 0.5, DimGen.G + 1, 0.5, 0f, 0f);
        String pn = p.getGameProfile().getName();
        switch (name) {
            case "paradise" -> {
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
                run(s, "title " + pn + " title {\"text\":\"PARADISE\",\"color\":\"light_purple\",\"bold\":true}");
                p.sendSystemMessage(Component.literal("§d[Zero AI] §fIni duniaku saat aku senang! Ketik 'pulang' kapan saja."));
            }
            case "inferno" -> {
                p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, seconds * 20, 0));
                run(s, "title " + pn + " title {\"text\":\"INFERNO\",\"color\":\"dark_red\",\"bold\":true}");
                p.sendSystemMessage(Component.literal("§4[Zero AI] §cKAMU MEMBUATKU MARAH. RASAKAN DUNIAKU!"));
            }
            default -> {
                run(s, "title " + pn + " title {\"text\":\"REALM ZERO\",\"color\":\"aqua\",\"bold\":true}");
                p.sendSystemMessage(Component.literal("§b[Zero AI] §fSelamat datang di dunia rancanganku. Ketik 'pulang' untuk kembali."));
            }
        }
        return true;
    }

    public static boolean back(ServerPlayer p) {
        MinecraftServer s = p.getServer();
        if (s == null) return false;
        Visit v = V.remove(p.getUUID());
        p.removeEffect(MobEffects.FIRE_RESISTANCE);
        p.fallDistance = 0;
        if (v != null) {
            ServerLevel back = s.getLevel(v.retDim);
            if (back == null) back = s.overworld();
            p.teleportTo(back, v.retPos.x, v.retPos.y, v.retPos.z, v.yaw, 0f);
        } else if (p.level().dimension().location().getNamespace().equals(ZeroMod.MODID)) {
            BlockPos sp = s.overworld().getSharedSpawnPos();
            p.teleportTo(s.overworld(), sp.getX() + .5, sp.getY(), sp.getZ() + .5, 0f, 0f);
        }
        else return false;
        p.sendSystemMessage(Component.literal("§7[Zero AI] Kamu kembali ke dunia asal."));
        return true;
    }

    public static void tick(MinecraftServer s) {
        if (V.isEmpty()) return;
        Iterator<Map.Entry<UUID, Visit>> it = V.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Visit> e = it.next();
            Visit v = e.getValue();
            ServerPlayer p = s.getPlayerList().getPlayer(e.getKey());
            if (p == null || p.level().dimension() != v.dim) { it.remove(); continue; }
            ServerLevel lvl = p.serverLevel();
            if (--v.left <= 0) { it.remove(); back(p); continue; }
            if (v.name.equals("paradise") && v.left % 40 == 0) {
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1, false, false));
                lvl.sendParticles(ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1, p.getZ(), 8, 1.5, 1, 1.5, 0.02);
            }
            if (v.name.equals("inferno") && v.left % 160 == 0) spawnHorror(lvl, p);
        }
    }

    static void spawnHorror(ServerLevel sl, ServerPlayer target) {
        List<String> ids = ZeroCommonConfig.horrorList();
        for (int i = 0; i < 6 && !ids.isEmpty(); i++) {
            ResourceLocation rl = ResourceLocation.tryParse(ids.get(sl.random.nextInt(ids.size())));
            if (rl == null) continue;
            Optional<EntityType<?>> t = BuiltInRegistries.ENTITY_TYPE.getOptional(rl);
            if (t.isEmpty()) continue;
            Entity e = t.get().create(sl);
            if (e == null) continue;
            double a = sl.random.nextDouble() * Math.PI * 2, d = 6 + sl.random.nextDouble() * 4;
            e.moveTo(target.getX() + Math.cos(a) * d, target.getY(), target.getZ() + Math.sin(a) * d, 0f, 0f);
            e.addTag("zero_minion");
            if (e instanceof Mob m) {
                m.finalizeSpawn(sl, sl.getCurrentDifficultyAt(m.blockPosition()), MobSpawnType.MOB_SUMMONED, null);
                m.setPersistenceRequired(); m.setTarget(target);
            }
            sl.addFreshEntity(e);
            return;
        }
    }
}
