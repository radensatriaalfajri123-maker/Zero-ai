package com.zeroai;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/** Dekorasi prosedural untuk dimensi Paradise (Zero senang) dan Inferno (Zero marah). Permukaan tanah di y=4. */
public final class DimGen {
    public static final int G = 4, R = 54;
    private static final int F = 2 | 16;

    private static BlockState s(Block b) { return b.defaultBlockState(); }
    private static void set(ServerLevel l, int x, int y, int z, BlockState st) { l.setBlock(new BlockPos(x, y, z), st, F); }
    private static boolean air(ServerLevel l, int x, int y, int z) { return l.getBlockState(new BlockPos(x, y, z)).isAir(); }
    private static BlockState leaves(Block b) { return b.defaultBlockState().setValue(BlockStateProperties.PERSISTENT, true); }

    public static boolean paradiseReady(ServerLevel l) { return l.getBlockState(new BlockPos(0, G - 1, 0)).is(Blocks.GOLD_BLOCK); }
    public static boolean infernoReady(ServerLevel l) { return l.getBlockState(new BlockPos(0, G - 1, 0)).is(Blocks.CRYING_OBSIDIAN); }

    private static int rnd(RandomSource r, int range) { return r.nextInt(range * 2 + 1) - range; }

    public static void paradise(ServerLevel l) {
        RandomSource r = RandomSource.create(777L);
        int px = -16, pz = -10;
        for (int dx = -6; dx <= 6; dx++) for (int dz = -6; dz <= 6; dz++) if (dx * dx + dz * dz <= 36) {
            set(l, px + dx, G, pz + dz, s(Blocks.WATER)); set(l, px + dx, G - 1, pz + dz, s(Blocks.SAND));
        }
        for (int z = 0; z <= 14; z++) for (int x = -1; x <= 1; x++) set(l, x, G, z, s(Blocks.DIRT_PATH));
        // kuil kuarsa
        int sz = 18;
        for (int dx = -4; dx <= 4; dx++) for (int dz = -4; dz <= 4; dz++) {
            set(l, dx, G, sz + dz, s(Blocks.QUARTZ_BLOCK));
            for (int y = 1; y <= 6; y++) set(l, dx, G + y, sz + dz, s(Blocks.AIR));
        }
        for (int cx : new int[]{-4, 4}) for (int cz : new int[]{-4, 4}) for (int y = 1; y <= 5; y++) set(l, cx, G + y, sz + cz, s(Blocks.QUARTZ_PILLAR));
        for (int dx = -5; dx <= 5; dx++) for (int dz = -5; dz <= 5; dz++) set(l, dx, G + 6, sz + dz, s(Blocks.QUARTZ_SLAB));
        set(l, 0, G + 6, sz, s(Blocks.SEA_LANTERN));
        set(l, 0, G + 1, sz, s(Blocks.BEACON));
        for (int i = 0; i < 70; i++) {
            int x = rnd(r, R), z = rnd(r, R);
            if (x * x + z * z < 64 || Math.abs(x) < 7 && z > 11 && z < 25 || (x - px) * (x - px) + (z - pz) * (z - pz) < 100) continue;
            tree(l, r, x, z, r.nextInt(3) != 0);
        }
        Block[] fl = {Blocks.POPPY, Blocks.DANDELION, Blocks.AZURE_BLUET, Blocks.CORNFLOWER, Blocks.OXEYE_DAISY, Blocks.ALLIUM, Blocks.PINK_TULIP, Blocks.LILY_OF_THE_VALLEY};
        for (int i = 0; i < 500; i++) {
            int x = rnd(r, R), z = rnd(r, R);
            if (l.getBlockState(new BlockPos(x, G, z)).is(Blocks.GRASS_BLOCK) && air(l, x, G + 1, z)) set(l, x, G + 1, z, s(fl[r.nextInt(fl.length)]));
        }
        for (int i = 0; i < 28; i++) {
            int x = rnd(r, R), z = rnd(r, R);
            if (!l.getBlockState(new BlockPos(x, G, z)).is(Blocks.GRASS_BLOCK)) continue;
            for (int y = 1; y <= 3; y++) set(l, x, G + y, z, s(Blocks.OAK_FENCE));
            set(l, x, G + 4, z, s(Blocks.LANTERN));
        }
        set(l, 0, G - 1, 0, s(Blocks.GOLD_BLOCK));
    }

    private static void tree(ServerLevel l, RandomSource r, int x, int z, boolean cherry) {
        if (!l.getBlockState(new BlockPos(x, G, z)).is(Blocks.GRASS_BLOCK)) return;
        int h = 4 + r.nextInt(3);
        Block log = cherry ? Blocks.CHERRY_LOG : Blocks.OAK_LOG, lf = cherry ? Blocks.CHERRY_LEAVES : Blocks.OAK_LEAVES;
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) for (int dy = h - 2; dy <= h + 1; dy++) {
            if (dx * dx + dz * dz + (dy - h + 1) * (dy - h + 1) > 6) continue;
            if (air(l, x + dx, G + dy, z + dz)) set(l, x + dx, G + dy, z + dz, leaves(lf));
        }
        for (int y = 1; y <= h; y++) set(l, x, G + y, z, s(log));
    }

    public static void inferno(ServerLevel l) {
        RandomSource r = RandomSource.create(666L);
        // danau lava
        for (int i = 0; i < 14; i++) {
            int cx = rnd(r, R), cz = rnd(r, R), rad = 3 + r.nextInt(4);
            if (cx * cx + cz * cz < (rad + 14) * (rad + 14)) continue;
            for (int dx = -rad; dx <= rad; dx++) for (int dz = -rad; dz <= rad; dz++) if (dx * dx + dz * dz <= rad * rad) {
                set(l, cx + dx, G, cz + dz, s(Blocks.LAVA)); set(l, cx + dx, G - 1, cz + dz, s(Blocks.LAVA));
            }
        }
        // pilar hitam
        for (int i = 0; i < 90; i++) {
            int x = rnd(r, R), z = rnd(r, R);
            if (x * x + z * z < 200) continue;
            Block b = r.nextBoolean() ? Blocks.BLACKSTONE : Blocks.BASALT;
            int h = 3 + r.nextInt(10);
            if (!l.getBlockState(new BlockPos(x, G, z)).is(Blocks.NETHERRACK)) continue;
            for (int y = 1; y <= h; y++) set(l, x, G + y, z, s(b));
            if (r.nextInt(3) == 0) set(l, x, G + h + 1, z, s(Blocks.SOUL_LANTERN));
        }
        for (int i = 0; i < 160; i++) {
            int x = rnd(r, R), z = rnd(r, R);
            if (l.getBlockState(new BlockPos(x, G, z)).is(Blocks.NETHERRACK) && air(l, x, G + 1, z)) set(l, x, G + 1, z, s(Blocks.FIRE));
        }
        for (int i = 0; i < 20; i++) {
            int cx = rnd(r, R), cz = rnd(r, R);
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++)
                if (dx * dx + dz * dz <= 5 && l.getBlockState(new BlockPos(cx + dx, G, cz + dz)).is(Blocks.NETHERRACK)) set(l, cx + dx, G, cz + dz, s(Blocks.SOUL_SAND));
        }
        // singgasana Zero
        for (int dx = -8; dx <= 8; dx++) for (int dz = -8; dz <= 8; dz++) {
            set(l, dx, G, dz, s((dx + dz) % 2 == 0 ? Blocks.NETHER_BRICKS : Blocks.RED_NETHER_BRICKS));
            for (int y = 1; y <= 12; y++) set(l, dx, G + y, dz, s(Blocks.AIR));
        }
        for (int cx : new int[]{-8, 0, 8}) for (int cz : new int[]{-8, 8}) for (int y = 1; y <= 7; y++) set(l, cx, G + y, cz, s(Blocks.CHISELED_NETHER_BRICKS));
        for (int y = 1; y <= 5; y++) { set(l, 0, G + y, -6, s(Blocks.CRYING_OBSIDIAN)); set(l, -1, G + y, -6, s(Blocks.OBSIDIAN)); set(l, 1, G + y, -6, s(Blocks.OBSIDIAN)); }
        set(l, 0, G + 1, -5, s(Blocks.RED_NETHER_BRICKS));
        for (int dx = -2; dx <= 2; dx++) set(l, dx, G + 1, -4, s(Blocks.NETHER_BRICK_FENCE));
        set(l, -5, G + 1, 0, s(Blocks.SOUL_FIRE)); set(l, 5, G + 1, 0, s(Blocks.SOUL_FIRE));
        set(l, 0, G - 1, 0, s(Blocks.CRYING_OBSIDIAN));
    }
}
