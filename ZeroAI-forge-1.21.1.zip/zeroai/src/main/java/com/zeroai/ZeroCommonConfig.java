package com.zeroai;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.ArrayList;
import java.util.List;

public final class ZeroCommonConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue HELPER_MOOD, SUMMON_INTERVAL_SEC, MAX_MINIONS, RAMPAGE_RADIUS, SPAM_SECONDS;
    public static final ForgeConfigSpec.BooleanValue DESTROY_BASE, KILL_ANIMALS, SUMMON_HORROR, BACKROOMS_ENABLED;
    public static final ForgeConfigSpec.ConfigValue<String> HORROR_MOBS, SPAM_TARGET;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        HELPER_MOOD = b.comment("Mood minimal agar Zero jadi penolong (tebang pohon, bunuh mob)").defineInRange("helperMood", 85, 50, 100);
        DESTROY_BASE = b.comment("Mode monster menghancurkan blok di sekitarnya (butuh gamerule mobGriefing true)").define("destroyBase", true);
        KILL_ANIMALS = b.define("killAnimals", true);
        SUMMON_HORROR = b.define("summonHorror", true);
        HORROR_MOBS = b.comment("ID entity yang disummon mode monster, pisah koma. Boleh isi mod horror, mis. modid:nama_entity. ID yang tidak ada dilewati.")
                .define("horrorMobs", "minecraft:zombie,minecraft:skeleton,minecraft:spider,minecraft:enderman,minecraft:phantom,minecraft:vex");
        SUMMON_INTERVAL_SEC = b.defineInRange("summonIntervalSeconds", 15, 3, 300);
        MAX_MINIONS = b.defineInRange("maxMinions", 6, 1, 30);
        RAMPAGE_RADIUS = b.defineInRange("rampageRadius", 5, 2, 12);
        BACKROOMS_ENABLED = b.comment("Jika pemain terbunuh Zero/pasukannya, kirim ke dimensi Backrooms").define("backroomsEnabled", true);
        SPAM_SECONDS = b.defineInRange("spamSeconds", 240, 10, 3600);
        SPAM_TARGET = b.comment("Target perintah /title setelah dimakan").define("spamTarget", "@a");
        SPEC = b.build();
    }

    public static List<String> horrorList() {
        List<String> l = new ArrayList<>();
        for (String s : HORROR_MOBS.get().split(",")) if (!s.isBlank()) l.add(s.trim());
        return l;
    }
}
