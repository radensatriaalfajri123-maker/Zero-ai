package com.zeroai;

import com.zeroai.entity.ZeroEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(ZeroMod.MODID)
public class ZeroMod {
    public static final String MODID = "zeroai";
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<EntityType<ZeroEntity>> ZERO = ENTITIES.register("zero",
            () -> EntityType.Builder.of(ZeroEntity::new, MobCategory.CREATURE)
                    .sized(0.7f, 1.9f).clientTrackingRange(10).build("zero"));
    public static final RegistryObject<Item> ZERO_EGG = ITEMS.register("zero_spawn_egg",
            () -> new SpawnEggItem(ZERO.get(), 0x55FFFF, 0x2B2B2B, new Item.Properties()));

    public ZeroMod(FMLJavaModLoadingContext ctx) {
        IEventBus bus = ctx.getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        ctx.registerConfig(ModConfig.Type.CLIENT, ZeroConfig.SPEC);
    }
}
