package com.zeroai.entity;

import com.zeroai.ZeroCommonConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.*;

public class ZeroEntity extends PathfinderMob implements GeoEntity {
    private static final EntityDataAccessor<Integer> MOOD = SynchedEntityData.defineId(ZeroEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> MONSTER = SynchedEntityData.defineId(ZeroEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> GIANT = SynchedEntityData.defineId(ZeroEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> EATING = SynchedEntityData.defineId(ZeroEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> WORKING = SynchedEntityData.defineId(ZeroEntity.class, EntityDataSerializers.BOOLEAN);

    private float moodExact = 70f;
    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private int transformUntil = -1;
    private final List<UUID> minions = new ArrayList<>();

    private static final RawAnimation A_IDLE = RawAnimation.begin().thenLoop("animation.zero.idle");
    private static final RawAnimation A_WALK = RawAnimation.begin().thenLoop("animation.zero.walk");
    private static final RawAnimation A_RUN = RawAnimation.begin().thenLoop("animation.zero.run");
    private static final RawAnimation A_MIDLE = RawAnimation.begin().thenLoop("animation.zero.monster_idle");
    private static final RawAnimation A_ATTACK = RawAnimation.begin().thenPlay("animation.zero.attack");
    private static final RawAnimation A_HATTACK = RawAnimation.begin().thenPlay("animation.zero.helper_attack");
    private static final RawAnimation A_BUILD = RawAnimation.begin().thenLoop("animation.zero.build");
    private static final RawAnimation A_SPAWN = RawAnimation.begin().thenPlay("animation.zero.spawn");
    private static final RawAnimation A_TRANSFORM = RawAnimation.begin().thenPlay("animation.zero.transform");
    private static final RawAnimation A_DEATH = RawAnimation.begin().thenPlayAndHold("animation.zero.death");
    private static final RawAnimation A_GIDLE = RawAnimation.begin().thenLoop("animation.zero.giant_idle");
    private static final RawAnimation A_GSPAWN = RawAnimation.begin().thenPlay("animation.zero.giant_spawn");
    private static final RawAnimation A_GEAT = RawAnimation.begin().thenPlayAndHold("animation.zero.giant_eat");
    private static final Map<String, RawAnimation> ACTIONS = new HashMap<>();

    public ZeroEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30).add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.ATTACK_DAMAGE, 5).add(Attributes.FOLLOW_RANGE, 40);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder b) {
        super.defineSynchedData(b);
        b.define(MOOD, 70);
        b.define(MONSTER, false);
        b.define(GIANT, false);
        b.define(EATING, false);
        b.define(WORKING, false);
    }

    public int getMood() { return entityData.get(MOOD); }
    public boolean isMonsterMode() { return entityData.get(MONSTER); }
    public boolean isGiant() { return entityData.get(GIANT); }
    public boolean isEating() { return entityData.get(EATING); }
    public boolean isWorking() { return entityData.get(WORKING); }
    public void setWorking(boolean v) { entityData.set(WORKING, v); }
    public void setEating(boolean v) { entityData.set(EATING, v); }
    public boolean isHelper() { return !isMonsterMode() && !isGiant() && getMood() >= ZeroCommonConfig.HELPER_MOOD.get(); }
    public boolean isSpawning() { return tickCount < 32; }
    public boolean isTransforming() { return tickCount < transformUntil; }

    /** Zero raksasa 10x untuk adegan Backrooms: dikendalikan manager, tanpa AI. */
    public void makeGiant() {
        entityData.set(GIANT, true);
        entityData.set(MONSTER, true);
        setNoAi(true);
        setInvulnerable(true);
        refreshDimensions();
    }

    // ---------------------------------------------------------------- animasi
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 4, this::predicate));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return geoCache; }

    private PlayState predicate(AnimationState<ZeroEntity> st) {
        if (isDeadOrDying()) return st.setAndContinue(A_DEATH);
        if (isGiant()) {
            if (isEating()) return st.setAndContinue(A_GEAT);
            if (isSpawning()) return st.setAndContinue(A_GSPAWN);
            return st.setAndContinue(A_GIDLE);
        }
        if (isSpawning()) return st.setAndContinue(A_SPAWN);
        if (isTransforming()) return st.setAndContinue(A_TRANSFORM);
        if (isMonsterMode()) {
            if (this.swinging) return st.setAndContinue(A_ATTACK);
            return st.setAndContinue(st.isMoving() ? A_RUN : A_MIDLE);
        }
        if (isWorking()) return st.setAndContinue(A_BUILD);
        if (this.swinging) return st.setAndContinue(A_HATTACK);
        String act = com.zeroai.client.ZeroClientState.actionFor(this);
        if (act != null) {
            RawAnimation ra = ACTIONS.computeIfAbsent(act, k -> RawAnimation.begin().thenLoop("animation.zero." + k));
            return st.setAndContinue(ra);
        }
        return st.setAndContinue(st.isMoving() ? A_WALK : A_IDLE);
    }

    // ---------------------------------------------------------------- AI
    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.3D, true) {
            @Override public boolean canUse() { return (isMonsterMode() || isHelper()) && super.canUse(); }
            @Override public boolean canContinueToUse() { return (isMonsterMode() || isHelper()) && super.canContinueToUse(); }
        });
        goalSelector.addGoal(2, new ChopTreeGoal(this));
        goalSelector.addGoal(3, new FollowPlayerGoal(this));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<Player>(this, Player.class, true) {
            @Override public boolean canUse() { return isMonsterMode() && super.canUse(); }
            @Override public boolean canContinueToUse() { return isMonsterMode() && super.canContinueToUse(); }
        });
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<Animal>(this, Animal.class, true) {
            @Override public boolean canUse() { return isMonsterMode() && ZeroCommonConfig.KILL_ANIMALS.get() && super.canUse(); }
            @Override public boolean canContinueToUse() { return isMonsterMode() && super.canContinueToUse(); }
        });
        targetSelector.addGoal(3, new NearestAttackableTargetGoal<Monster>(this, Monster.class, true) {
            @Override public boolean canUse() { return isHelper() && super.canUse(); }
            @Override public boolean canContinueToUse() { return isHelper() && super.canContinueToUse(); }
        });
    }

    static class FollowPlayerGoal extends Goal {
        private final ZeroEntity z;
        private Player target;
        FollowPlayerGoal(ZeroEntity z) { this.z = z; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() {
            if (z.isMonsterMode()) return false;
            target = z.level().getNearestPlayer(z, 40);
            return target != null && z.distanceToSqr(target) > 25;
        }
        @Override public boolean canContinueToUse() {
            return target != null && target.isAlive() && !z.isMonsterMode() && z.distanceToSqr(target) > 9;
        }
        @Override public void tick() {
            if (z.distanceToSqr(target) > 900) z.teleportTo(target.getX(), target.getY(), target.getZ());
            else if (z.tickCount % 10 == 0) z.getNavigation().moveTo(target, 1.15);
        }
        @Override public void stop() { z.getNavigation().stop(); target = null; }
    }

    /** Mode penolong: mencari pohon alami terdekat (ada daun) lalu menebangnya. */
    static class ChopTreeGoal extends Goal {
        private final ZeroEntity z;
        private final ArrayDeque<BlockPos> tree = new ArrayDeque<>();
        private BlockPos base;
        private int cd;
        ChopTreeGoal(ZeroEntity z) { this.z = z; setFlags(EnumSet.of(Flag.MOVE)); }

        @Override public boolean canUse() {
            if (!z.isHelper() || z.getRandom().nextInt(25) != 0) return false;
            Level lv = z.level(); BlockPos c = z.blockPosition();
            List<BlockPos> cands = new ArrayList<>();
            for (int dx = -14; dx <= 14; dx++) for (int dz = -14; dz <= 14; dz++) for (int dy = -3; dy <= 6; dy++) {
                BlockPos p = c.offset(dx, dy, dz);
                if (lv.getBlockState(p).is(BlockTags.LOGS) && lv.getBlockState(p.below()).is(BlockTags.DIRT)) cands.add(p);
            }
            cands.sort(Comparator.comparingDouble(p -> p.distSqr(c)));
            for (int i = 0; i < Math.min(6, cands.size()); i++) {
                List<BlockPos> logs = collect(lv, cands.get(i));
                if (logs != null) {
                    logs.sort((a, b) -> Integer.compare(b.getY(), a.getY()));
                    tree.clear(); tree.addAll(logs); base = cands.get(i);
                    return true;
                }
            }
            return false;
        }

        private List<BlockPos> collect(Level lv, BlockPos start) {
            Set<BlockPos> seen = new HashSet<>(); ArrayDeque<BlockPos> q = new ArrayDeque<>();
            q.add(start); seen.add(start);
            boolean leaves = false;
            while (!q.isEmpty() && seen.size() < 150) {
                BlockPos p = q.poll();
                for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                    BlockPos n = p.offset(dx, dy, dz);
                    if (!seen.contains(n) && lv.getBlockState(n).is(BlockTags.LOGS)) { seen.add(n); q.add(n); }
                }
                if (!leaves) for (int dx = -2; dx <= 2 && !leaves; dx++) for (int dy = 0; dy <= 2 && !leaves; dy++) for (int dz = -2; dz <= 2; dz++)
                    if (lv.getBlockState(p.offset(dx, dy, dz)).is(BlockTags.LEAVES)) { leaves = true; break; }
            }
            return leaves ? new ArrayList<>(seen) : null;
        }

        @Override public void start() { z.setWorking(true); }
        @Override public boolean canContinueToUse() { return z.isHelper() && !tree.isEmpty() && base != null; }
        @Override public void tick() {
            double bx = base.getX() + .5, by = base.getY(), bz = base.getZ() + .5;
            if (z.distanceToSqr(bx, by, bz) > 36) {
                if (z.tickCount % 10 == 0) z.getNavigation().moveTo(bx, by, bz, 1.1);
                return;
            }
            z.getNavigation().stop();
            z.getLookControl().setLookAt(Vec3.atCenterOf(base));
            if (++cd >= 5) {
                cd = 0;
                BlockPos p = tree.pollFirst();
                if (p != null && z.level().getBlockState(p).is(BlockTags.LOGS)) z.level().destroyBlock(p, true, z);
                z.swing(InteractionHand.MAIN_HAND);
            }
        }
        @Override public void stop() { z.setWorking(false); tree.clear(); base = null; z.getNavigation().stop(); }
    }

    // ---------------------------------------------------------------- tick server
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if ((isMonsterMode() || isGiant()) && random.nextInt(isGiant() ? 1 : 3) == 0)
                level().addParticle(ParticleTypes.LARGE_SMOKE, getX() + (random.nextDouble() - 0.5) * (isGiant() ? 6 : 1), getY() + random.nextDouble() * (isGiant() ? 16 : 1.8),
                        getZ() + (random.nextDouble() - 0.5) * (isGiant() ? 6 : 1), 0, 0.05, 0);
            return;
        }
        if (isGiant()) return;
        if (tickCount % 20 == 0) {
            float d;
            if (isMonsterMode()) d = 0.35f;
            else if (level().getNearestPlayer(this, 12) != null) d = 0.08f;
            else if (level().getNearestPlayer(this, 32) == null) d = -0.15f;
            else d = -0.03f;
            if (isInWaterOrRain()) d -= 0.1f;
            addMood(d);
        }
        if (isMonsterMode() && level() instanceof ServerLevel sl) rampage(sl);
    }

    private void rampage(ServerLevel sl) {
        if (ZeroCommonConfig.DESTROY_BASE.get() && tickCount % 3 == 0 && sl.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            int r = ZeroCommonConfig.RAMPAGE_RADIUS.get(), n = 0;
            BlockPos c = blockPosition();
            outer:
            for (int dy = 0; dy <= r + 1; dy++) for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
                if (dx * dx + dz * dz + dy * dy > r * r + r) continue;
                BlockPos p = c.offset(dx, dy, dz);
                BlockState st = sl.getBlockState(p);
                if (st.isAir() || st.getDestroySpeed(sl, p) < 0) continue;
                sl.destroyBlock(p, false, this);
                if (++n >= 90) break outer;
            }
        }
        if (tickCount % 50 == 0) {
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), 12, 1, 1, 1, 0.05);
            playSound(SoundEvents.IRON_GOLEM_DEATH, 1.2f, 0.5f);
        }
        if (ZeroCommonConfig.SUMMON_HORROR.get() && tickCount % (ZeroCommonConfig.SUMMON_INTERVAL_SEC.get() * 20) == 0) summonMinion(sl);
        if (tickCount % 40 == 0) {
            minions.removeIf(u -> { Entity e = sl.getEntity(u); return e == null || !e.isAlive(); });
            Player pl = sl.getNearestPlayer(this, 64);
            if (pl != null) for (UUID u : minions) if (sl.getEntity(u) instanceof Mob m && m.getTarget() == null) m.setTarget(pl);
        }
    }

    private void summonMinion(ServerLevel sl) {
        minions.removeIf(u -> { Entity e = sl.getEntity(u); return e == null || !e.isAlive(); });
        if (minions.size() >= ZeroCommonConfig.MAX_MINIONS.get()) return;
        List<String> ids = ZeroCommonConfig.horrorList();
        for (int i = 0; i < 6 && !ids.isEmpty(); i++) {
            ResourceLocation rl = ResourceLocation.tryParse(ids.get(random.nextInt(ids.size())));
            if (rl == null) continue;
            Optional<EntityType<?>> t = BuiltInRegistries.ENTITY_TYPE.getOptional(rl);
            if (t.isEmpty()) continue;
            Entity e = t.get().create(sl);
            if (e == null) continue;
            double a = random.nextDouble() * Math.PI * 2, d = 5 + random.nextDouble() * 6;
            e.moveTo(getX() + Math.cos(a) * d, getY(), getZ() + Math.sin(a) * d, random.nextFloat() * 360f, 0f);
            e.addTag("zero_minion");
            if (e instanceof Mob m) {
                m.finalizeSpawn(sl, sl.getCurrentDifficultyAt(m.blockPosition()), MobSpawnType.MOB_SUMMONED, null);
                m.setPersistenceRequired();
                Player pl = sl.getNearestPlayer(this, 64);
                if (pl != null) m.setTarget(pl);
            }
            sl.addFreshEntity(e);
            minions.add(e.getUUID());
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, e.getX(), e.getY() + 1, e.getZ(), 20, .4, .8, .4, 0.05);
            return;
        }
    }

    private void discardMinions() {
        if (level() instanceof ServerLevel sl) for (UUID u : minions) { Entity e = sl.getEntity(u); if (e != null) e.discard(); }
        minions.clear();
    }

    @Override
    public void die(DamageSource src) {
        super.die(src);
        if (!level().isClientSide) discardMinions();
    }

    // ---------------------------------------------------------------- mood
    public void setMood(float v) {
        if (level().isClientSide) return;
        moodExact = Mth.clamp(v, 0f, 100f);
        int m = Math.round(moodExact);
        if (m != getMood()) entityData.set(MOOD, m);
        if (!isMonsterMode() && !isGiant() && m <= 10) transform(true);
        else if (isMonsterMode() && !isGiant() && m >= 40) transform(false);
    }
    public void addMood(float d) { setMood(moodExact + d); }

    private void applyStats(boolean m) {
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(m ? 9 : 5);
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(m ? 0.36 : 0.28);
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(m ? 60 : 30);
        getAttribute(Attributes.FOLLOW_RANGE).setBaseValue(m ? 64 : 40);
        if (m) heal(30f); else if (getHealth() > 30f) setHealth(30f);
    }

    private void transform(boolean m) {
        entityData.set(MONSTER, m);
        applyStats(m);
        playSound(m ? SoundEvents.WITHER_SPAWN : SoundEvents.BEACON_ACTIVATE, 0.8f, m ? 0.6f : 1.4f);
        if (level() instanceof ServerLevel sl)
            sl.sendParticles(m ? ParticleTypes.LARGE_SMOKE : ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 1, getZ(), 30, 0.5, 0.8, 0.5, 0.05);
        for (Player p : level().players()) {
            if (p.distanceToSqr(this) < 4096)
                p.sendSystemMessage(Component.literal(m
                        ? "§4§l[ZERO AI] §c*** MOOD HANCUR! ZERO BERUBAH JADI MONSTER! ***"
                        : "§b[ZERO AI] §fBEEP... aku sudah tenang lagi."));
        }
        if (!m) { setTarget(null); discardMinions(); }
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (MONSTER.equals(key) || GIANT.equals(key)) {
            refreshDimensions();
            if (MONSTER.equals(key) && level().isClientSide && tickCount > 5 && !isGiant()) transformUntil = tickCount + 42;
        }
        super.onSyncedDataUpdated(key);
    }

    @Override
    public EntityDimensions getDefaultDimensions(Pose pose) {
        EntityDimensions d = super.getDefaultDimensions(pose);
        return isGiant() ? d.scale(10f) : isMonsterMode() ? d.scale(1.4f) : d;
    }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (isGiant()) return false;
        boolean r = super.hurt(src, amount);
        if (r && !level().isClientSide) addMood(src.getEntity() instanceof Player ? -6 : -2);
        return r;
    }

    private static int gift(ItemStack s) {
        if (s.is(Items.ENCHANTED_GOLDEN_APPLE)) return 50;
        if (s.is(Items.GOLDEN_APPLE)) return 25;
        if (s.is(Items.DIAMOND)) return 20;
        if (s.is(Items.CAKE)) return 15;
        if (s.is(Items.IRON_INGOT)) return 8;
        if (s.is(Items.REDSTONE)) return 5;
        return 0;
    }

    @Override
    protected InteractionResult mobInteract(Player p, InteractionHand h) {
        if (isGiant()) return InteractionResult.PASS;
        ItemStack s = p.getItemInHand(h);
        int g = gift(s);
        if (g > 0) {
            if (!level().isClientSide) {
                if (!p.getAbilities().instabuild) s.shrink(1);
                addMood(g);
                ((ServerLevel) level()).sendParticles(ParticleTypes.HEART, getX(), getY() + 1.6, getZ(), 6, 0.3, 0.3, 0.3, 0.02);
                playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1f, 1.5f);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(p, h);
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean isPushable() { return !isGiant() && super.isPushable(); }
    @Override public boolean shouldBeSaved() { return !isGiant() && super.shouldBeSaved(); }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.IRON_GOLEM_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.IRON_GOLEM_DEATH; }

    @Override
    public boolean shouldShowName() { return !isGiant(); }

    @Override
    public Component getDisplayName() {
        int m = getMood();
        ChatFormatting c = m >= 60 ? ChatFormatting.GREEN : m >= 30 ? ChatFormatting.YELLOW : ChatFormatting.RED;
        String bar = "█".repeat(m / 10) + "░".repeat(10 - m / 10);
        String nm = isMonsterMode() ? "☠ ZERO AI (MONSTER)" : isHelper() ? "★ Zero AI (Penolong)" : "Zero AI";
        MutableComponent n = Component.literal(nm)
                .withStyle(isMonsterMode() ? ChatFormatting.DARK_RED : isHelper() ? ChatFormatting.GOLD : ChatFormatting.AQUA);
        return n.append(Component.literal(" [" + bar + "]").withStyle(c));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putFloat("Mood", moodExact);
        t.putBoolean("MonsterMode", isMonsterMode());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        if (t.contains("Mood")) moodExact = t.getFloat("Mood");
        entityData.set(MOOD, Math.round(moodExact));
        boolean m = t.getBoolean("MonsterMode");
        entityData.set(MONSTER, m);
        applyStats(m);
    }
}
