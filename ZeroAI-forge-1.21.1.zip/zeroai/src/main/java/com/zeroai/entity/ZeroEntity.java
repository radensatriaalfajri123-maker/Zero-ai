package com.zeroai.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.ChatFormatting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

import java.util.EnumSet;

public class ZeroEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> MOOD = SynchedEntityData.defineId(ZeroEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> MONSTER = SynchedEntityData.defineId(ZeroEntity.class, EntityDataSerializers.BOOLEAN);
    private float moodExact = 70f;

    public ZeroEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30).add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.ATTACK_DAMAGE, 3).add(Attributes.FOLLOW_RANGE, 32);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder b) {
        super.defineSynchedData(b);
        b.define(MOOD, 70);
        b.define(MONSTER, false);
    }

    public int getMood() { return entityData.get(MOOD); }
    public boolean isMonsterMode() { return entityData.get(MONSTER); }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.3D, true) {
            @Override public boolean canUse() { return isMonsterMode() && super.canUse(); }
            @Override public boolean canContinueToUse() { return isMonsterMode() && super.canContinueToUse(); }
        });
        goalSelector.addGoal(3, new FollowPlayerGoal(this));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<Player>(this, Player.class, true) {
            @Override public boolean canUse() { return isMonsterMode() && super.canUse(); }
            @Override public boolean canContinueToUse() { return isMonsterMode() && super.canContinueToUse(); }
        });
    }

    static class FollowPlayerGoal extends Goal {
        private final ZeroEntity z;
        private Player target;
        FollowPlayerGoal(ZeroEntity z) { this.z = z; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() {
            if (z.isMonsterMode()) return false;
            target = z.level().getNearestPlayer(z, 40);
            return target != null && z.distanceToSqr(target) > 25;
        }
        @Override public boolean canContinueToUse() {
            return target != null && target.isAlive() && !z.isMonsterMode() && z.distanceToSqr(target) > 9;
        }
        @Override public void tick() {
            if (z.distanceToSqr(target) > 900) z.teleportTo(target.getX(), target.getY(), target.getZ());
            else if (z.tickCount % 10 == 0) z.getNavigation().moveTo(target, 1.15);
        }
        @Override public void stop() { z.getNavigation().stop(); target = null; }
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (isMonsterMode() && random.nextInt(3) == 0)
                level().addParticle(ParticleTypes.LARGE_SMOKE, getX() + (random.nextDouble() - 0.5), getY() + 1.0 + random.nextDouble(), getZ() + (random.nextDouble() - 0.5), 0, 0.05, 0);
            return;
        }
        if (tickCount % 20 == 0) {
            float d;
            if (isMonsterMode()) d = 0.35f;
            else if (level().getNearestPlayer(this, 12) != null) d = 0.08f;
            else if (level().getNearestPlayer(this, 32) == null) d = -0.15f;
            else d = -0.03f;
            if (isInWaterOrRain()) d -= 0.1f;
            addMood(d);
        }
    }

    public void setMood(float v) {
        if (level().isClientSide) return;
        moodExact = Mth.clamp(v, 0f, 100f);
        int m = Math.round(moodExact);
        if (m != getMood()) entityData.set(MOOD, m);
        if (!isMonsterMode() && m <= 10) transform(true);
        else if (isMonsterMode() && m >= 40) transform(false);
    }
    public void addMood(float d) { setMood(moodExact + d); }

    private void applyStats(boolean m) {
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(m ? 9 : 3);
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(m ? 0.36 : 0.28);
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(m ? 60 : 30);
        if (m) heal(30f); else if (getHealth() > 30f) setHealth(30f);
    }

    private void transform(boolean m) {
        entityData.set(MONSTER, m);
        applyStats(m);
        playSound(m ? SoundEvents.WITHER_SPAWN : SoundEvents.BEACON_ACTIVATE, 0.8f, m ? 0.6f : 1.4f);
        if (level() instanceof ServerLevel sl)
            sl.sendParticles(m ? ParticleTypes.LARGE_SMOKE : ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 1, getZ(), 30, 0.5, 0.8, 0.5, 0.05);
        for (Player p : level().players()) {
            if (p.distanceToSqr(this) < 4096)
                p.sendSystemMessage(Component.literal(m
                        ? "§4§l[ZERO AI] §c*** MOOD HANCUR! ZERO BERUBAH JADI MONSTER! ***"
                        : "§b[ZERO AI] §fBEEP... aku sudah tenang lagi."));
        }
        if (!m) setTarget(null);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (MONSTER.equals(key)) refreshDimensions();
        super.onSyncedDataUpdated(key);
    }

    @Override
    public EntityDimensions getDefaultDimensions(Pose pose) {
        EntityDimensions d = super.getDefaultDimensions(pose);
        return isMonsterMode() ? d.scale(1.4f) : d;
    }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        boolean r = super.hurt(src, amount);
        if (r && !level().isClientSide) addMood(src.getEntity() instanceof Player ? -6 : -2);
        return r;
    }

    private static int gift(ItemStack s) {
        if (s.is(Items.ENCHANTED_GOLDEN_APPLE)) return 50;
        if (s.is(Items.GOLDEN_APPLE)) return 25;
        if (s.is(Items.DIAMOND)) return 20;
        if (s.is(Items.CAKE)) return 15;
        if (s.is(Items.IRON_INGOT)) return 8;
        if (s.is(Items.REDSTONE)) return 5;
        return 0;
    }

    @Override
    protected InteractionResult mobInteract(Player p, InteractionHand h) {
        ItemStack s = p.getItemInHand(h);
        int g = gift(s);
        if (g > 0) {
            if (!level().isClientSide) {
                if (!p.getAbilities().instabuild) s.shrink(1);
                addMood(g);
                ((ServerLevel) level()).sendParticles(ParticleTypes.HEART, getX(), getY() + 1.6, getZ(), 6, 0.3, 0.3, 0.3, 0.02);
                playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1f, 1.5f);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(p, h);
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.IRON_GOLEM_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.IRON_GOLEM_DEATH; }

    @Override
    public boolean shouldShowName() { return true; }

    @Override
    public Component getDisplayName() {
        int m = getMood();
        ChatFormatting c = m >= 60 ? ChatFormatting.GREEN : m >= 30 ? ChatFormatting.YELLOW : ChatFormatting.RED;
        String bar = "█".repeat(m / 10) + "░".repeat(10 - m / 10);
        MutableComponent n = Component.literal(isMonsterMode() ? "☠ ZERO AI (MONSTER)" : "Zero AI")
                .withStyle(isMonsterMode() ? ChatFormatting.DARK_RED : ChatFormatting.AQUA);
        return n.append(Component.literal(" [" + bar + "]").withStyle(c));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putFloat("Mood", moodExact);
        t.putBoolean("MonsterMode", isMonsterMode());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        if (t.contains("Mood")) moodExact = t.getFloat("Mood");
        entityData.set(MOOD, Math.round(moodExact));
        boolean m = t.getBoolean("MonsterMode");
        entityData.set(MONSTER, m);
        applyStats(m);
    }
}
