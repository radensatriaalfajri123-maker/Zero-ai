package com.zeroai;

import com.zeroai.entity.ZeroEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** Alur: terbunuh Zero/pasukannya -> Backrooms -> masuk aula -> Zero raksasa memakan -> spam /title -> dikembalikan. */
public final class BackroomsManager {
    public static final ResourceKey<Level> DIM = ResourceKey.create(Registries.DIMENSION, ResourceLocation.fromNamespaceAndPath(ZeroMod.MODID, "backrooms"));
    private enum Stage { ARRIVED, EATING, SPAM }
    private static final class St {
        Stage stage = Stage.ARRIVED; ResourceKey<Level> retDim; Vec3 retPos; float yaw;
        boolean giantSpawned; UUID giant; int t; int spam; Vec3 start;
    }
    private static final Map<UUID, St> S = new HashMap<>();
    private static int spamClock;
    private static final double CX = 103.5, CZ = 103.5;

    public static boolean isIn(UUID id) { return S.containsKey(id); }

    private static void run(MinecraftServer s, String cmd) {
        s.getCommands().performPrefixedCommand(s.createCommandSourceStack().withSuppressedOutput(), cmd);
    }

    /** @return true jika pemain berhasil dikirim (kematian harus dibatalkan). */
    public static boolean send(ServerPlayer p, Entity killer) {
        if (S.containsKey(p.getUUID())) return false;
        MinecraftServer srv = p.getServer();
        if (srv == null) return false;
        ServerLevel lvl = srv.getLevel(DIM);
        if (lvl == null) return false;
        if (!BackroomsGen.generated(lvl)) BackroomsGen.generate(lvl);
        St st = new St();
        st.retDim = p.level().dimension(); st.retPos = p.position(); st.yaw = p.getYRot();
        S.put(p.getUUID(), st);
        if (killer instanceof Mob m) m.setTarget(null);
        p.setHealth(Math.max(8f, p.getMaxHealth() / 2f));
        p.clearFire();
        p.fallDistance = 0;
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 4));
        p.teleportTo(lvl, BackroomsGen.START_X, BackroomsGen.FLOOR + 1, BackroomsGen.START_Z, 0f, 0f);
        run(srv, "title " + p.getGameProfile().getName() + " title {\"text\":\"BACKROOMS\",\"color\":\"yellow\"}");
        p.sendSystemMessage(Component.literal("§e...kamu terjatuh keluar dari realita. Jangan masuk ke ruangan besar."));
        return true;
    }

    public static void tick(MinecraftServer s) {
        if (S.isEmpty()) return;
        ServerLevel lvl = s.getLevel(DIM);
        boolean anySpam = false;
        Iterator<Map.Entry<UUID, St>> it = S.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, St> e = it.next();
            St st = e.getValue();
            ServerPlayer p = s.getPlayerList().getPlayer(e.getKey());
            if (p == null || lvl == null) { it.remove(); continue; }
            switch (st.stage) {
                case ARRIVED -> arrived(lvl, p, st);
                case EATING -> eating(lvl, p, st);
                case SPAM -> {
                    anySpam = true;
                    if (++st.spam >= ZeroCommonConfig.SPAM_SECONDS.get() * 20) { release(s, p, st); it.remove(); }
                }
            }
        }
        if (anySpam && ++spamClock % 6 == 0)
            run(s, "title " + ZeroCommonConfig.SPAM_TARGET.get() + " title {\"text\":\"you're too much\",\"color\":\"dark_red\",\"bold\":true}");
    }

    private static void face(ZeroEntity g, double tx, double tz) {
        float yaw = (float) (Mth.atan2(tz - g.getZ(), tx - g.getX()) * 57.29578) - 90f;
        g.setYRot(yaw); g.yBodyRot = yaw; g.yHeadRot = yaw;
    }

    private static void arrived(ServerLevel lvl, ServerPlayer p, St st) {
        if (p.level().dimension() != DIM) return;
        double x = p.getX(), z = p.getZ();
        if (!st.giantSpawned) {
            if (x >= BackroomsGen.HALL_MIN + 2 && x <= BackroomsGen.HALL_MAX - 2 && z >= BackroomsGen.HALL_MIN + 2 && z <= BackroomsGen.HALL_MAX - 2) {
                double vx = CX - x, vz = CZ - z, len = Math.sqrt(vx * vx + vz * vz);
                if (len < 6) { vx = 1; vz = 0; len = 1; }
                double gx = Mth.clamp(x + vx / len * 24, 86, 120), gz = Mth.clamp(z + vz / len * 24, 86, 120);
                ZeroEntity g = ZeroMod.ZERO.get().create(lvl);
                if (g == null) return;
                g.makeGiant();
                g.moveTo(gx, BackroomsGen.FLOOR + 1, gz, 0f, 0f);
                face(g, x, z);
                lvl.addFreshEntity(g);
                st.giant = g.getUUID(); st.giantSpawned = true; st.t = 0;
                g.playSound(SoundEvents.WITHER_SPAWN, 6f, 0.4f);
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 400, 9, false, false));
                p.addEffect(new MobEffectInstance(MobEffects.JUMP, 400, 128, false, false));
                p.sendSystemMessage(Component.literal("§4§l*** ZERO ***"));
            }
            return;
        }
        Entity ge = lvl.getEntity(st.giant);
        if (!(ge instanceof ZeroEntity g)) { st.giantSpawned = false; return; }
        face(g, x, z);
        if (++st.t >= 45) {
            double dx = x - g.getX(), dz = z - g.getZ(), len = Math.max(0.01, Math.sqrt(dx * dx + dz * dz));
            g.moveTo(x - dx / len * 6.5, BackroomsGen.FLOOR + 1, z - dz / len * 6.5, g.getYRot(), 0f);
            face(g, x, z);
            g.setEating(true);
            st.stage = Stage.EATING; st.t = 0; st.start = p.position();
        }
    }

    private static void eating(ServerLevel lvl, ServerPlayer p, St st) {
        Entity ge = lvl.getEntity(st.giant);
        if (!(ge instanceof ZeroEntity g)) { st.stage = Stage.ARRIVED; st.giantSpawned = false; return; }
        int t = st.t++;
        double yawR = Math.toRadians(g.getYRot());
        double fx = -Math.sin(yawR), fz = Math.cos(yawR);
        Vec3 mouth = new Vec3(g.getX() + fx * 2.2, g.getY() + 12.0, g.getZ() + fz * 2.2);
        if (t == 0) g.playSound(SoundEvents.WITHER_SPAWN, 6f, 0.5f);
        if (t >= 10 && t <= 46) {
            double s = Mth.clamp((t - 10) / 36.0, 0, 1); s = s * s * (3 - 2 * s);
            p.setNoGravity(true); p.fallDistance = 0; p.setDeltaMovement(Vec3.ZERO);
            p.connection.teleport(Mth.lerp(s, st.start.x, mouth.x), Mth.lerp(s, st.start.y, mouth.y), Mth.lerp(s, st.start.z, mouth.z), p.getYRot(), p.getXRot());
        }
        if (t == 44) p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 400, 0, false, false));
        if (t == 48 || t == 56 || t == 64) {
            g.playSound(SoundEvents.IRON_GOLEM_DEATH, 6f, 0.35f);
            p.playSound(SoundEvents.IRON_GOLEM_HURT, 1f, 0.5f);
            lvl.sendParticles(net.minecraft.core.particles.ParticleTypes.LARGE_SMOKE, mouth.x, mouth.y, mouth.z, 25, 1, 1, 1, 0.1);
        }
        if (t >= 82) {
            g.setEating(false); g.discard();
            p.setNoGravity(false); p.fallDistance = 0;
            p.teleportTo(lvl, BackroomsGen.BELLY_X, BackroomsGen.FLOOR + 1, BackroomsGen.BELLY_Z, 0f, 0f);
            p.removeEffect(MobEffects.MOVEMENT_SLOWDOWN); p.removeEffect(MobEffects.JUMP);
            p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, ZeroCommonConfig.SPAM_SECONDS.get() * 20, 0, false, false));
            run(lvl.getServer(), "title " + ZeroCommonConfig.SPAM_TARGET.get() + " times 0 12 6");
            st.stage = Stage.SPAM; st.spam = 0;
        }
    }

    private static void release(MinecraftServer s, ServerPlayer p, St st) {
        ServerLevel back = s.getLevel(st.retDim);
        if (back == null) back = s.overworld();
        p.removeEffect(MobEffects.DARKNESS); p.removeEffect(MobEffects.BLINDNESS);
        p.setNoGravity(false);
        p.teleportTo(back, st.retPos.x, st.retPos.y, st.retPos.z, st.yaw, 0f);
        run(s, "title " + p.getGameProfile().getName() + " clear");
        p.sendSystemMessage(Component.literal("§7...kamu kembali. Zero masih mengawasimu."));
    }
}
