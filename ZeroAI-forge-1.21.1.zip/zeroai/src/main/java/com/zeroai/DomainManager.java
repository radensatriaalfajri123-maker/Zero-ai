package com.zeroai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** "Wilayah Zero": area di overworld berubah jadi Paradise (senang) atau Inferno (marah), lalu dipulihkan. */
public final class DomainManager {
    private static final int R = 26, H = 28, BELOW = 5;
    private static final int F = 2 | 16;

    private static final class Dom {
        ServerLevel lvl; BlockPos c; String type; int left;
        int[] sy; BlockState[][] snap; int w;
    }
    private static final List<Dom> ACTIVE = new ArrayList<>();

    public static boolean active(ServerLevel l, BlockPos p) {
        for (Dom d : ACTIVE) if (d.lvl == l && d.c.distSqr(p) < 4.0 * R * R) return true;
        return false;
    }

    private static void run(MinecraftServer s, String cmd) {
        s.getCommands().performPrefixedCommand(s.createCommandSourceStack().withSuppressedOutput(), cmd);
    }

    private static boolean natural(BlockState b) {
        return b.is(BlockTags.DIRT) || b.is(BlockTags.SAND) || b.is(BlockTags.BASE_STONE_OVERWORLD) || b.is(Blocks.GRAVEL)
                || b.is(Blocks.SNOW_BLOCK) || b.is(Blocks.CLAY) || b.is(BlockTags.TERRACOTTA) || b.is(Blocks.PODZOL) || b.is(Blocks.MYCELIUM);
    }
    private static void set(ServerLevel l, int x, int y, int z, BlockState s) { l.setBlock(new BlockPos(x, y, z), s, F); }

    public static boolean open(ServerLevel l, BlockPos c, String type, int seconds) {
        if (active(l, c)) return false;
        Dom d = new Dom();
        d.lvl = l; d.c = c; d.type = type; d.left = seconds * 20; d.w = 2 * R + 1;
        d.sy = new int[d.w * d.w]; d.snap = new BlockState[d.w * d.w][];
        RandomSource r = l.random;
        for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++) {
            int d2 = dx * dx + dz * dz;
            if (d2 > R * R || (d2 > (R - 4) * (R - 4) && r.nextFloat() < 0.4f)) continue;
            int x = c.getX() + dx, z = c.getZ() + dz;
            if (!l.hasChunkAt(new BlockPos(x, 64, z))) continue;
            int sy = l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            int idx = (dx + R) * d.w + (dz + R);
            d.sy[idx] = sy;
            BlockState[] col = new BlockState[H];
            for (int i = 0; i < H; i++) col[i] = l.getBlockState(new BlockPos(x, sy - BELOW + i, z));
            d.snap[idx] = col;
            if (type.equals("paradise")) paradise(l, r, x, z, sy); else inferno(l, r, x, z, sy);
        }
        ACTIVE.add(d);
        MinecraftServer s = l.getServer();
        String title = type.equals("paradise")
                ? "{\"text\":\"DOMAIN: PARADISE\",\"color\":\"light_purple\",\"bold\":true}"
                : "{\"text\":\"DOMAIN: INFERNO\",\"color\":\"dark_red\",\"bold\":true}";
        run(s, "execute positioned " + c.getX() + " " + c.getY() + " " + c.getZ() + " run title @a[distance=..60] title " + title);
        for (ServerPlayer p : l.players())
            if (p.distanceToSqr(c.getX(), c.getY(), c.getZ()) < 3600)
                p.sendSystemMessage(Component.literal(type.equals("paradise")
                        ? "§d[Zero AI] §fAku lagi senang! Rasakan duniaku!" : "§4[Zero AI] §cKAMU MEMBUATKU MARAH. TERIMA WILAYAHKU!"));
        return true;
    }

    private static void paradise(ServerLevel l, RandomSource r, int x, int z, int sy) {
        BlockPos below = new BlockPos(x, sy - 1, z);
        BlockState bs = l.getBlockState(below);
        if (natural(bs)) {
            set(l, x, sy - 1, z, Blocks.GRASS_BLOCK.defaultBlockState());
            for (int i = 2; i <= 3; i++) if (natural(l.getBlockState(new BlockPos(x, sy - i, z)))) set(l, x, sy - i, z, Blocks.DIRT.defaultBlockState());
            BlockState up = l.getBlockState(new BlockPos(x, sy, z));
            if (up.is(Blocks.SNOW)) { set(l, x, sy, z, Blocks.AIR.defaultBlockState()); up = Blocks.AIR.defaultBlockState(); }
            if (up.isAir()) {
                float f = r.nextFloat();
                Block[] fl = {Blocks.POPPY, Blocks.DANDELION, Blocks.AZURE_BLUET, Blocks.CORNFLOWER, Blocks.OXEYE_DAISY, Blocks.ALLIUM, Blocks.PINK_TULIP};
                if (f < 0.07f) set(l, x, sy, z, fl[r.nextInt(fl.length)].defaultBlockState());
                else if (f < 0.075f) tree(l, r, x, z, sy);
                else if (f < 0.0765f) { for (int y = 0; y < 3; y++) set(l, x, sy + y, z, Blocks.OAK_FENCE.defaultBlockState()); set(l, x, sy + 3, z, Blocks.LANTERN.defaultBlockState()); }
            }
        }
    }

    private static void tree(ServerLevel l, RandomSource r, int x, int z, int sy) {
        int h = 4 + r.nextInt(3);
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) for (int dy = h - 2; dy <= h + 1; dy++) {
            if (dx * dx + dz * dz + (dy - h + 1) * (dy - h + 1) > 6) continue;
            BlockPos p = new BlockPos(x + dx, sy + dy, z + dz);
            if (l.getBlockState(p).isAir()) l.setBlock(p, Blocks.CHERRY_LEAVES.defaultBlockState().setValue(BlockStateProperties.PERSISTENT, true), F);
        }
        for (int y = 0; y < h; y++) set(l, x, sy + y, z, Blocks.CHERRY_LOG.defaultBlockState());
    }

    private static void inferno(ServerLevel l, RandomSource r, int x, int z, int sy) {
        BlockPos below = new BlockPos(x, sy - 1, z);
        BlockState bs = l.getBlockState(below);
        if (bs.getFluidState().is(net.minecraft.tags.FluidTags.WATER)) { set(l, x, sy - 1, z, Blocks.LAVA.defaultBlockState()); return; }
        if (!natural(bs)) return;
        for (int i = 1; i <= 3; i++) {
            if (!natural(l.getBlockState(new BlockPos(x, sy - i, z)))) continue;
            float f = r.nextFloat();
            set(l, x, sy - i, z, (f < 0.06f ? Blocks.MAGMA_BLOCK : f < 0.12f ? Blocks.SOUL_SAND : Blocks.NETHERRACK).defaultBlockState());
        }
        BlockState up = l.getBlockState(new BlockPos(x, sy, z));
        if (up.is(Blocks.SNOW)) { set(l, x, sy, z, Blocks.AIR.defaultBlockState()); up = Blocks.AIR.defaultBlockState(); }
        if (up.isAir()) {
            float f = r.nextFloat();
            if (f < 0.05f) set(l, x, sy, z, Blocks.FIRE.defaultBlockState());
            else if (f < 0.057f) { int h = 3 + r.nextInt(7); for (int y = 0; y < h; y++) set(l, x, sy + y, z, (r.nextBoolean() ? Blocks.BLACKSTONE : Blocks.BASALT).defaultBlockState()); }
        }
    }

    public static void tick(MinecraftServer s) {
        if (ACTIVE.isEmpty()) return;
        Iterator<Dom> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Dom d = it.next();
            if (--d.left <= 0) { restore(d); it.remove(); continue; }
            if (d.left % 20 != 0) continue;
            boolean para = d.type.equals("paradise");
            for (ServerPlayer p : d.lvl.players()) {
                double dx = p.getX() - d.c.getX(), dz = p.getZ() - d.c.getZ();
                if (dx * dx + dz * dz > (R + 4) * (R + 4)) continue;
                if (para) {
                    p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 1, false, false));
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 0, false, false));
                    d.lvl.sendParticles(ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1, p.getZ(), 6, 1.5, 1, 1.5, 0.02);
                } else {
                    if (!p.fireImmune() && !p.hasEffect(MobEffects.FIRE_RESISTANCE)) p.setRemainingFireTicks(40);
                    p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0, false, false));
                    d.lvl.sendParticles(ParticleTypes.LARGE_SMOKE, p.getX(), p.getY() + 1, p.getZ(), 6, 2, 1, 2, 0.02);
                    if (d.left % 160 == 0) DimManager.spawnHorror(d.lvl, p);
                }
            }
        }
    }

    private static void restore(Dom d) {
        for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++) {
            int idx = (dx + R) * d.w + (dz + R);
            BlockState[] col = d.snap[idx];
            if (col == null) continue;
            int x = d.c.getX() + dx, z = d.c.getZ() + dz, sy = d.sy[idx];
            for (int i = 0; i < H; i++) d.lvl.setBlock(new BlockPos(x, sy - BELOW + i, z), col[i], F);
        }
        AABB box = new AABB(d.c).inflate(R + 12);
        for (Mob m : d.lvl.getEntitiesOfClass(Mob.class, box)) if (m.getTags().contains("zero_minion")) m.discard();
        for (ServerPlayer p : d.lvl.players()) if (p.distanceToSqr(d.c.getX(), d.c.getY(), d.c.getZ()) < 4900)
            p.sendSystemMessage(Component.literal("§7[Zero AI] Wilayahku menghilang... dunia kembali seperti semula."));
    }

    /** Akhiri wilayah terdekat lebih cepat. */
    public static boolean end(ServerLevel l, BlockPos p) {
        for (Iterator<Dom> it = ACTIVE.iterator(); it.hasNext(); ) {
            Dom d = it.next();
            if (d.lvl == l && d.c.distSqr(p) < 4.0 * R * R) { restore(d); it.remove(); return true; }
        }
        return false;
    }
}
