package com.zeroai;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Membangun labirin Backrooms + aula besar + "perut" Zero di dimensi zeroai:backrooms. */
public final class BackroomsGen {
    public static final int FLOOR = 64, CELL = 8, N = 16;
    public static final int HALL_MIN = 80, HALL_MAX = 126, HALL_CEIL = 94;
    public static final double START_X = 3.5, START_Z = 3.5, BELLY_X = 154.5, BELLY_Z = 14.5;
    private static final BlockState WALL = Blocks.SMOOTH_SANDSTONE.defaultBlockState();
    private static final BlockState FLOOR_B = Blocks.BROWN_TERRACOTTA.defaultBlockState();
    private static final BlockState CEIL_B = Blocks.WHITE_CONCRETE.defaultBlockState();
    private static final BlockState LIGHT = Blocks.GLOWSTONE.defaultBlockState();
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState FLESH = Blocks.NETHER_WART_BLOCK.defaultBlockState();
    private static final int F = 2 | 16;

    public static boolean generated(ServerLevel l) {
        return l.getBlockState(new BlockPos(4, FLOOR, 4)).is(FLOOR_B.getBlock());
    }

    private static void set(ServerLevel l, int x, int y, int z, BlockState s) { l.setBlock(new BlockPos(x, y, z), s, F); }
    private static void fill(ServerLevel l, int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = x1; x <= x2; x++) for (int y = y1; y <= y2; y++) for (int z = z1; z <= z2; z++) l.setBlock(m.set(x, y, z), s, F);
    }

    public static void generate(ServerLevel l) {
        RandomSource rnd = RandomSource.create(1337L);
        int size = N * CELL;
        // 1) blok padat dengan lantai & langit-langit
        for (int x = 0; x < size; x++) for (int z = 0; z < size; z++) {
            set(l, x, FLOOR, z, FLOOR_B);
            fill(l, x, FLOOR + 1, z, x, FLOOR + 3, z, WALL);
            set(l, x, FLOOR + 4, z, CEIL_B);
        }
        // 2) labirin DFS
        boolean[][] oe = new boolean[N][N], os = new boolean[N][N], vis = new boolean[N][N];
        ArrayDeque<int[]> st = new ArrayDeque<>();
        st.push(new int[]{0, 0}); vis[0][0] = true;
        while (!st.isEmpty()) {
            int[] c = st.peek();
            List<int[]> nb = new ArrayList<>();
            if (c[0] + 1 < N && !vis[c[0] + 1][c[1]]) nb.add(new int[]{c[0] + 1, c[1], 0});
            if (c[0] - 1 >= 0 && !vis[c[0] - 1][c[1]]) nb.add(new int[]{c[0] - 1, c[1], 1});
            if (c[1] + 1 < N && !vis[c[0]][c[1] + 1]) nb.add(new int[]{c[0], c[1] + 1, 2});
            if (c[1] - 1 >= 0 && !vis[c[0]][c[1] - 1]) nb.add(new int[]{c[0], c[1] - 1, 3});
            if (nb.isEmpty()) { st.pop(); continue; }
            int[] n = nb.get(rnd.nextInt(nb.size()));
            switch (n[2]) { case 0 -> oe[c[0]][c[1]] = true; case 1 -> oe[n[0]][n[1]] = true;
                case 2 -> os[c[0]][c[1]] = true; default -> os[n[0]][n[1]] = true; }
            vis[n[0]][n[1]] = true; st.push(new int[]{n[0], n[1]});
        }
        for (int cx = 0; cx < N; cx++) for (int cz = 0; cz < N; cz++) {
            if (cx < N - 1 && rnd.nextFloat() < 0.18f) oe[cx][cz] = true;
            if (cz < N - 1 && rnd.nextFloat() < 0.18f) os[cx][cz] = true;
        }
        for (int cx = 0; cx < N; cx++) for (int cz = 0; cz < N; cz++) {
            int ox = cx * CELL, oz = cz * CELL;
            fill(l, ox, FLOOR + 1, oz, ox + 6, FLOOR + 3, oz + 6, AIR);
            if (oe[cx][cz] && cx < N - 1) fill(l, ox + 7, FLOOR + 1, oz + 2, ox + 7, FLOOR + 3, oz + 4, AIR);
            if (os[cx][cz] && cz < N - 1) fill(l, ox + 2, FLOOR + 1, oz + 7, ox + 4, FLOOR + 3, oz + 7, AIR);
            set(l, ox + 3, FLOOR + 4, oz + 3, LIGHT);
            if (rnd.nextFloat() < 0.5f) set(l, ox + 1, FLOOR + 4, oz + 5, LIGHT);
            for (int k = 0; k < 2; k++) if (rnd.nextFloat() < 0.4f) fill(l, ox + 1 + rnd.nextInt(5), FLOOR + 1, oz + 1 + rnd.nextInt(5), ox + 1 + rnd.nextInt(5), FLOOR + 3, oz + 1 + rnd.nextInt(5), WALL);
        }
        // 3) aula besar (tempat Zero raksasa muncul)
        int a = HALL_MIN - 1, b = HALL_MAX + 1;
        fill(l, a, FLOOR + 1, a, b, HALL_CEIL, b, WALL);
        fill(l, HALL_MIN, FLOOR + 1, HALL_MIN, HALL_MAX, HALL_CEIL - 1, HALL_MAX, AIR);
        for (int x = a; x <= b; x++) for (int z = a; z <= b; z++) { set(l, x, FLOOR, z, FLOOR_B); set(l, x, HALL_CEIL, z, CEIL_B); }
        for (int x = HALL_MIN + 4; x < HALL_MAX; x += 8) for (int z = HALL_MIN + 4; z < HALL_MAX; z += 8) set(l, x, HALL_CEIL, z, LIGHT);
        for (int px : new int[]{90, 116}) for (int pz : new int[]{90, 116}) fill(l, px, FLOOR + 1, pz, px + 2, HALL_CEIL - 1, pz + 2, WALL);
        fill(l, a, FLOOR + 1, 98, a, FLOOR + 3, 100, AIR);   // pintu barat
        fill(l, 98, FLOOR + 1, a, 100, FLOOR + 3, a, AIR);   // pintu utara
        // 4) "perut" Zero
        fill(l, 150, FLOOR, 10, 158, FLOOR + 6, 18, FLESH);
        fill(l, 151, FLOOR + 1, 11, 157, FLOOR + 4, 17, AIR);
        set(l, 154, FLOOR + 5, 14, Blocks.SHROOMLIGHT.defaultBlockState());
    }
}
