package com.zeroai.client;

import com.zeroai.ZeroConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

import java.util.*;
import java.util.function.Supplier;

/** Musik robot 8-bit dari suara note block vanilla (tanpa file audio tambahan). */
public final class ZeroMusic {
    private record Track(Supplier<SoundEvent> inst, int[] seq) {}
    private static final Map<String, Track> TRACKS = new LinkedHashMap<>();
    private static Track cur;
    private static int idx, wait;

    static {
        TRACKS.put("robot_dance", new Track(() -> SoundEvents.NOTE_BLOCK_BIT.value(), new int[]{12,3,15,3,19,3,15,3,17,3,14,3,17,3,21,3,12,3,15,3,19,3,24,6,-1,3,22,3,19,3,15,3,12,9}));
        TRACKS.put("happy", new Track(() -> SoundEvents.NOTE_BLOCK_IRON_XYLOPHONE.value(), new int[]{12,3,16,3,19,3,24,6,19,3,24,3,23,3,21,3,19,3,16,3,12,9}));
        TRACKS.put("sad_beep", new Track(() -> SoundEvents.NOTE_BLOCK_BIT.value(), new int[]{17,6,15,6,12,6,10,12,-1,6,12,6,10,6,7,12}));
        TRACKS.put("space", new Track(() -> SoundEvents.NOTE_BLOCK_PLING.value(), new int[]{0,4,7,4,12,4,16,4,19,4,16,4,12,4,7,4,2,4,9,4,14,4,17,4,21,4,17,4,14,4,9,4}));
        TRACKS.put("boss", new Track(() -> SoundEvents.NOTE_BLOCK_DIDGERIDOO.value(), new int[]{0,5,0,5,3,5,0,5,6,5,5,5,3,5,0,10,-1,5,0,3,0,3,1,3,0,3,7,10}));
    }

    public static Set<String> names() { return TRACKS.keySet(); }

    public static void play(String name) {
        if (name == null) return;
        name = name.trim().toLowerCase(Locale.ROOT);
        if (name.equals("stop")) { cur = null; return; }
        if (!ZeroConfig.MUSIC_ENABLED.get()) return;
        Track t = TRACKS.get(name);
        if (t != null) { cur = t; idx = 0; wait = 0; }
    }

    public static void beep(int note) {
        if (!ZeroConfig.MUSIC_ENABLED.get()) return;
        float pitch = (float) Math.pow(2.0, (note - 12) / 12.0);
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_BIT.value(), pitch, 0.35f));
    }

    public static void tick() {
        if (cur == null) return;
        if (wait > 0) { wait--; return; }
        int note = cur.seq[idx], dur = cur.seq[idx + 1];
        if (note >= 0) {
            float pitch = (float) Math.pow(2.0, (note - 12) / 12.0);
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(cur.inst.get(), pitch, 0.7f));
        }
        wait = dur - 1;
        idx += 2;
        if (idx >= cur.seq.length) idx = 0;
    }
}
