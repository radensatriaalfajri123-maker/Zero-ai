package com.zeroai.client;

import javax.sound.sampled.*;
import java.io.*;

public final class MicRecorder {
    private static final AudioFormat FMT = new AudioFormat(16000f, 16, 1, true, false);
    private static final Object LOCK = new Object();
    private static volatile boolean recording;
    private static TargetDataLine line;
    private static ByteArrayOutputStream buf;

    public static boolean isRecording() { return recording; }

    public static boolean start() {
        try {
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, FMT);
            if (!AudioSystem.isLineSupported(info)) return false;
            line = (TargetDataLine) AudioSystem.getLine(info);
            line.open(FMT);
            line.start();
            buf = new ByteArrayOutputStream();
            recording = true;
            final TargetDataLine l = line;
            Thread t = new Thread(() -> {
                byte[] b = new byte[3200];
                while (recording) {
                    int n = l.read(b, 0, b.length);
                    if (n > 0) synchronized (LOCK) { buf.write(b, 0, n); }
                    if (buf.size() > 32000 * 30) break;
                }
            }, "zero-mic");
            t.setDaemon(true);
            t.start();
            return true;
        } catch (Exception e) {
            recording = false;
            return false;
        }
    }

    /** @return data WAV, atau null jika terlalu pendek */
    public static byte[] stop() {
        if (!recording) return null;
        recording = false;
        try { if (line != null) { line.stop(); line.close(); } } catch (Exception ignored) {}
        line = null;
        byte[] pcm;
        synchronized (LOCK) { pcm = buf.toByteArray(); }
        if (pcm.length < 32000 * 0.4) return null;
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
             AudioInputStream ais = new AudioInputStream(new ByteArrayInputStream(pcm), FMT, pcm.length / 2)) {
            AudioSystem.write(ais, AudioFileFormat.Type.WAVE, out);
            return out.toByteArray();
        } catch (IOException e) {
            return null;
        }
    }
}
