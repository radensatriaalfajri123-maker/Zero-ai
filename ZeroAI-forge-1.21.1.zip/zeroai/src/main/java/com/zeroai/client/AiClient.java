package com.zeroai.client;

import com.google.gson.*;
import com.zeroai.ZeroConfig;
import com.zeroai.ZeroConfig.Provider;

import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;

public final class AiClient {
    public static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
    public record Msg(String role, String text) {}

    private static String trunc(String s, int n) { return s.length() > n ? s.substring(0, n) + "..." : s; }

    private static JsonObject obj(String role, String content) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", content);
        return o;
    }

    // ------------------------------------------------ CHAT
    public static CompletableFuture<String> chat(String system, List<Msg> hist) {
        try {
            Provider p = ZeroConfig.PROVIDER.get();
            String model = ZeroConfig.modelFor(p);
            if (model.isBlank()) throw new IllegalStateException("Model belum diisi (tekan K untuk pengaturan)");
            if (p != Provider.OLLAMA && ZeroConfig.keyFor(p).isBlank())
                throw new IllegalStateException("API key " + p + " belum diisi (tekan K untuk pengaturan)");
            HttpRequest req = switch (p) {
                case OLLAMA -> ollama(model, system, hist);
                case GEMINI -> gemini(model, system, hist);
                default -> openaiLike(p, model, system, hist);
            };
            return HTTP.sendAsync(req, HttpResponse.BodyHandlers.ofString()).thenApply(r -> parseChat(p, r));
        } catch (Exception e) {
            return CompletableFuture.failedFuture(e);
        }
    }

    private static HttpRequest openaiLike(Provider p, String model, String system, List<Msg> hist) {
        JsonObject b = new JsonObject();
        b.addProperty("model", model);
        JsonArray msgs = new JsonArray();
        msgs.add(obj("system", system));
        for (Msg m : hist) msgs.add(obj(m.role(), m.text()));
        b.add("messages", msgs);
        String url = p == Provider.GROQ ? "https://api.groq.com/openai/v1/chat/completions" : "https://api.openai.com/v1/chat/completions";
        return HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(90))
                .header("Authorization", "Bearer " + ZeroConfig.keyFor(p))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(b.toString())).build();
    }

    private static HttpRequest ollama(String model, String system, List<Msg> hist) {
        JsonObject b = new JsonObject();
        b.addProperty("model", model);
        b.addProperty("stream", false);
        JsonArray msgs = new JsonArray();
        msgs.add(obj("system", system));
        for (Msg m : hist) msgs.add(obj(m.role(), m.text()));
        b.add("messages", msgs);
        JsonObject opt = new JsonObject(); opt.addProperty("num_predict", 4096); opt.addProperty("num_ctx", 8192);
        b.add("options", opt);
        String base = ZeroConfig.OLLAMA_URL.get().trim().replaceAll("/+$", "");
        return HttpRequest.newBuilder(URI.create(base + "/api/chat")).timeout(Duration.ofSeconds(180))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(b.toString())).build();
    }

    private static HttpRequest gemini(String model, String system, List<Msg> hist) {
        JsonObject b = new JsonObject();
        JsonObject si = new JsonObject();
        JsonArray sp = new JsonArray();
        JsonObject st = new JsonObject(); st.addProperty("text", system); sp.add(st);
        si.add("parts", sp);
        b.add("systemInstruction", si);
        JsonArray contents = new JsonArray();
        for (Msg m : hist) {
            JsonObject c = new JsonObject();
            c.addProperty("role", m.role().equals("assistant") ? "model" : "user");
            JsonArray parts = new JsonArray();
            JsonObject t = new JsonObject(); t.addProperty("text", m.text()); parts.add(t);
            c.add("parts", parts);
            contents.add(c);
        }
        b.add("contents", contents);
        return HttpRequest.newBuilder(URI.create("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent"))
                .timeout(Duration.ofSeconds(90))
                .header("x-goog-api-key", ZeroConfig.GEMINI_KEY.get())
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(b.toString())).build();
    }

    private static String parseChat(Provider p, HttpResponse<String> r) {
        if (r.statusCode() / 100 != 2) throw new RuntimeException("HTTP " + r.statusCode() + ": " + trunc(r.body(), 240));
        JsonObject o = JsonParser.parseString(r.body()).getAsJsonObject();
        switch (p) {
            case OLLAMA:
                return o.getAsJsonObject("message").get("content").getAsString();
            case GEMINI: {
                StringBuilder sb = new StringBuilder();
                for (JsonElement e : o.getAsJsonArray("candidates").get(0).getAsJsonObject()
                        .getAsJsonObject("content").getAsJsonArray("parts")) {
                    JsonObject po = e.getAsJsonObject();
                    if (po.has("text")) sb.append(po.get("text").getAsString());
                }
                return sb.toString();
            }
            default: {
                JsonElement c = o.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message").get("content");
                return c == null || c.isJsonNull() ? "" : c.getAsString();
            }
        }
    }

    // ------------------------------------------------ SPEECH TO TEXT
    public static CompletableFuture<String> transcribe(byte[] wav) {
        try {
            Provider p = ZeroConfig.PROVIDER.get();
            if (p == Provider.OLLAMA) { // Ollama tidak punya STT -> pakai Groq/OpenAI jika ada key
                if (!ZeroConfig.GROQ_KEY.get().isBlank()) p = Provider.GROQ;
                else if (!ZeroConfig.OPENAI_KEY.get().isBlank()) p = Provider.OPENAI;
                else throw new IllegalStateException("Ollama tidak bisa speech-to-text. Isi key Groq atau OpenAI di pengaturan (K).");
            }
            if (ZeroConfig.keyFor(p).isBlank()) throw new IllegalStateException("API key " + p + " belum diisi (tekan K)");
            final Provider fp = p;
            HttpRequest req = p == Provider.GEMINI ? geminiStt(wav) : whisper(p, wav);
            return HTTP.sendAsync(req, HttpResponse.BodyHandlers.ofString()).thenApply(r -> {
                if (r.statusCode() / 100 != 2) throw new RuntimeException("STT HTTP " + r.statusCode() + ": " + trunc(r.body(), 200));
                if (fp == Provider.GEMINI) return parseChat(Provider.GEMINI, r).trim();
                return JsonParser.parseString(r.body()).getAsJsonObject().get("text").getAsString().trim();
            });
        } catch (Exception e) {
            return CompletableFuture.failedFuture(e);
        }
    }

    private static HttpRequest geminiStt(byte[] wav) {
        JsonObject b = new JsonObject();
        JsonArray parts = new JsonArray();
        JsonObject t = new JsonObject();
        t.addProperty("text", "Transkripsikan audio ini apa adanya. Balas HANYA dengan teks yang diucapkan, tanpa komentar.");
        parts.add(t);
        JsonObject d = new JsonObject(); d.addProperty("mime_type", "audio/wav");
        d.addProperty("data", Base64.getEncoder().encodeToString(wav));
        JsonObject ip = new JsonObject(); ip.add("inline_data", d); parts.add(ip);
        JsonObject c = new JsonObject(); c.addProperty("role", "user"); c.add("parts", parts);
        JsonArray contents = new JsonArray(); contents.add(c);
        b.add("contents", contents);
        return HttpRequest.newBuilder(URI.create("https://generativelanguage.googleapis.com/v1beta/models/" + ZeroConfig.GEMINI_MODEL.get() + ":generateContent"))
                .timeout(Duration.ofSeconds(60))
                .header("x-goog-api-key", ZeroConfig.GEMINI_KEY.get())
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(b.toString())).build();
    }

    private static HttpRequest whisper(Provider p, byte[] wav) throws Exception {
        String boundary = "----zero" + System.nanoTime();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        String model = p == Provider.GROQ ? ZeroConfig.STT_MODEL_GROQ.get() : ZeroConfig.STT_MODEL_OPENAI.get();
        field(o, boundary, "model", model);
        field(o, boundary, "response_format", "json");
        String lang = ZeroConfig.STT_LANG.get().trim();
        if (!lang.isEmpty()) field(o, boundary, "language", lang);
        o.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\nContent-Type: audio/wav\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        o.write(wav);
        o.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
        String url = p == Provider.GROQ ? "https://api.groq.com/openai/v1/audio/transcriptions" : "https://api.openai.com/v1/audio/transcriptions";
        return HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + ZeroConfig.keyFor(p))
                .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                .POST(HttpRequest.BodyPublishers.ofByteArray(o.toByteArray())).build();
    }

    private static void field(ByteArrayOutputStream o, String boundary, String name, String val) throws Exception {
        o.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" + val + "\r\n").getBytes(StandardCharsets.UTF_8));
    }

    // ------------------------------------------------ DAFTAR MODEL
    public static CompletableFuture<List<String>> listModels() {
        try {
            Provider p = ZeroConfig.PROVIDER.get();
            HttpRequest.Builder rb;
            switch (p) {
                case OLLAMA -> rb = HttpRequest.newBuilder(URI.create(ZeroConfig.OLLAMA_URL.get().trim().replaceAll("/+$", "") + "/api/tags"));
                case GROQ -> rb = HttpRequest.newBuilder(URI.create("https://api.groq.com/openai/v1/models")).header("Authorization", "Bearer " + ZeroConfig.GROQ_KEY.get());
                case OPENAI -> rb = HttpRequest.newBuilder(URI.create("https://api.openai.com/v1/models")).header("Authorization", "Bearer " + ZeroConfig.OPENAI_KEY.get());
                default -> rb = HttpRequest.newBuilder(URI.create("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200")).header("x-goog-api-key", ZeroConfig.GEMINI_KEY.get());
            }
            return HTTP.sendAsync(rb.timeout(Duration.ofSeconds(20)).GET().build(), HttpResponse.BodyHandlers.ofString()).thenApply(r -> {
                if (r.statusCode() / 100 != 2) throw new RuntimeException("HTTP " + r.statusCode() + ": " + trunc(r.body(), 160));
                JsonObject o = JsonParser.parseString(r.body()).getAsJsonObject();
                List<String> out = new ArrayList<>();
                if (p == Provider.OLLAMA) for (JsonElement e : o.getAsJsonArray("models")) out.add(e.getAsJsonObject().get("name").getAsString());
                else if (p == Provider.GEMINI) {
                    for (JsonElement e : o.getAsJsonArray("models")) {
                        JsonObject m = e.getAsJsonObject();
                        if (m.has("supportedGenerationMethods") && m.get("supportedGenerationMethods").toString().contains("generateContent"))
                            out.add(m.get("name").getAsString().replace("models/", ""));
                    }
                } else for (JsonElement e : o.getAsJsonArray("data")) {
                    String id = e.getAsJsonObject().get("id").getAsString();
                    if (!id.contains("whisper") && !id.contains("tts") && !id.contains("embed") && !id.contains("guard")) out.add(id);
                }
                Collections.sort(out);
                return out;
            });
        } catch (Exception e) {
            return CompletableFuture.failedFuture(e);
        }
    }
}
