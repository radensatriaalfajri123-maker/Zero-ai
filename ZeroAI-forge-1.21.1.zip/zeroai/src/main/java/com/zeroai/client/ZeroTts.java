package com.zeroai.client;

import com.google.gson.JsonObject;
import com.zeroai.ZeroConfig;

import javax.sound.sampled.*;
import java.io.*;
import java.net.URI;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public final class ZeroTts {
    private static final ExecutorService EX = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "zero-tts"); t.setDaemon(true); return t;
    });
    private static final AtomicInteger GEN = new AtomicInteger();
    private static volatile Process proc;
    private static volatile Clip clip;

    public static String clean(String s) {
        return s.replaceAll("[*_#`~>\\[\\]]", "").replaceAll("\\s+", " ").trim();
    }

    public static void stop() {
        Process p = proc; if (p != null) p.destroyForcibly();
        Clip c = clip; if (c != null) c.stop();
    }

    public static void speak(String raw) {
        String text = clean(raw);
        if (text.isEmpty()) return;
        long est = Math.max(1500, text.length() * 85L);
        ZeroClientState.startTalking(est + 2000);
        if (!ZeroConfig.TTS_ENABLED.get()) { ZeroClientState.startTalking(est); return; }
        stop();
        final int my = GEN.incrementAndGet();
        EX.submit(() -> {
            try {
                if (ZeroConfig.TTS_MODE.get() == ZeroConfig.TtsMode.OPENAI && !ZeroConfig.OPENAI_KEY.get().isBlank()) openai(text);
                else system(text);
            } catch (Exception e) {
                System.err.println("[ZeroAI] TTS error: " + e);
            } finally {
                if (GEN.get() == my) ZeroClientState.stopTalking();
            }
        });
    }

    private static void system(String text) throws Exception {
        String os = System.getProperty("os.name").toLowerCase();
        List<String> cmd;
        if (os.contains("win")) cmd = List.of("powershell", "-NoProfile", "-NonInteractive", "-Command",
                "[Console]::InputEncoding=[System.Text.Encoding]::UTF8; Add-Type -AssemblyName System.Speech; "
                        + "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer; $t=[Console]::In.ReadToEnd(); $s.Speak($t)");
        else if (os.contains("mac")) cmd = List.of("say", "-v", "Zarvox");
        else cmd = List.of("espeak-ng", "-p", "20", "-s", "150");
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        proc = p;
        try (OutputStream o = p.getOutputStream()) { o.write(text.getBytes(StandardCharsets.UTF_8)); }
        p.getInputStream().transferTo(OutputStream.nullOutputStream());
        p.waitFor();
    }

    private static void openai(String text) throws Exception {
        JsonObject b = new JsonObject();
        b.addProperty("model", ZeroConfig.TTS_MODEL.get());
        b.addProperty("input", text);
        b.addProperty("voice", ZeroConfig.TTS_VOICE.get());
        b.addProperty("response_format", "wav");
        HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.openai.com/v1/audio/speech"))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + ZeroConfig.OPENAI_KEY.get())
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(b.toString())).build();
        HttpResponse<byte[]> r = AiClient.HTTP.send(req, HttpResponse.BodyHandlers.ofByteArray());
        if (r.statusCode() / 100 != 2) throw new IOException("TTS HTTP " + r.statusCode());
        try (AudioInputStream in = AudioSystem.getAudioInputStream(new BufferedInputStream(new ByteArrayInputStream(r.body())))) {
            Clip c = AudioSystem.getClip();
            CountDownLatch done = new CountDownLatch(1);
            c.addLineListener(ev -> { if (ev.getType() == LineEvent.Type.STOP) done.countDown(); });
            c.open(in);
            clip = c;
            c.start();
            done.await(120, TimeUnit.SECONDS);
            c.close();
        }
    }
}
