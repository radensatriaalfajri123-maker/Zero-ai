package com.zeroai.client;

import com.zeroai.entity.ZeroEntity;
import net.minecraft.client.Minecraft;

import java.util.Comparator;
import java.util.List;

public final class ZeroClientState {
    private static volatile long talkingUntil;
    private static volatile int talkingId = -1;
    public static ZeroEntity cached;
    private static boolean wasMonster;

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        cached = null;
        if (mc.player == null || mc.level == null) return;
        List<ZeroEntity> l = mc.level.getEntitiesOfClass(ZeroEntity.class, mc.player.getBoundingBox().inflate(64));
        if (!l.isEmpty()) cached = l.stream().min(Comparator.comparingDouble(z -> z.distanceToSqr(mc.player))).get();
        boolean m = cached != null && cached.isMonsterMode();
        if (m && !wasMonster) ZeroMusic.play("boss");
        if (!m && wasMonster) ZeroMusic.play("stop");
        wasMonster = m;
    }
    public static int mood() { return cached == null ? 70 : cached.getMood(); }
    public static boolean isTalking(ZeroEntity e) { return e.getId() == talkingId && System.currentTimeMillis() < talkingUntil; }
    public static void startTalking(long ms) {
        if (cached != null) { talkingId = cached.getId(); talkingUntil = System.currentTimeMillis() + ms; }
    }
    public static void stopTalking() { talkingUntil = 0; }
}
