package com.zeroai.client;

import com.zeroai.entity.ZeroEntity;
import net.minecraft.client.Minecraft;

import java.util.Comparator;
import java.util.List;

public final class ZeroClientState {
    private static volatile long talkingUntil;
    private static volatile long actionUntil;
    private static volatile String action;
    public static ZeroEntity cached;
    private static boolean wasMonster;

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        cached = null;
        if (mc.player == null || mc.level == null) return;
        List<ZeroEntity> l = mc.level.getEntitiesOfClass(ZeroEntity.class, mc.player.getBoundingBox().inflate(64));
        if (!l.isEmpty()) cached = l.stream().min(Comparator.comparingDouble(z -> z.distanceToSqr(mc.player))).get();
        boolean m = cached != null && cached.isMonsterMode();
        if (m && !wasMonster) ZeroMusic.play("boss");
        if (!m && wasMonster) ZeroMusic.play("stop");
        wasMonster = m;
    }
    public static int mood() { return cached == null ? 70 : cached.getMood(); }

    public static void startTalking(long ms) { talkingUntil = System.currentTimeMillis() + ms; }
    public static void stopTalking() { talkingUntil = 0; }

    /** Animasi emote dari AI: wave, dance, happy, sad, scan, think, talk. */
    public static void setAction(String name, long ms) {
        action = name; actionUntil = System.currentTimeMillis() + ms;
    }

    /** Nama animasi (tanpa prefix) yang harus diputar entity ini, atau null untuk idle/walk. */
    public static String actionFor(ZeroEntity e) {
        if (cached == null || e.getId() != cached.getId()) return null;
        long now = System.currentTimeMillis();
        if (MicRecorder.isRecording()) return "listen";
        if (action != null && now < actionUntil) return action;
        if (ZeroBrain.isThinking()) return "think";
        if (now < talkingUntil) return "talk";
        return null;
    }
}
