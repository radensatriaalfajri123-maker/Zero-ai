package com.zeroai.client;

import com.zeroai.ZeroMod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ZeroMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) { e.register(ZeroKeys.TALK); e.register(ZeroKeys.CONFIG); }
    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) { e.registerEntityRenderer(ZeroMod.ZERO.get(), ZeroRenderer::new); }
    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) { e.registerLayerDefinition(ZeroModel.LAYER, ZeroModel::createLayer); }
}
