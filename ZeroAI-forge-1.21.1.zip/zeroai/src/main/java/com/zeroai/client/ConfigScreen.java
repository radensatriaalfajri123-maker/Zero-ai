package com.zeroai.client;

import com.zeroai.ZeroConfig;
import com.zeroai.ZeroConfig.Provider;
import com.zeroai.ZeroConfig.TtsMode;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

public class ConfigScreen extends Screen {
    private final Screen parent;
    private Provider provider;
    private EditBox modelBox, keyBox, urlBox, langBox;
    private List<String> fetched = List.of();
    private int fetchIdx = -1;
    private String status = "";

    public ConfigScreen(Screen parent) {
        super(Component.literal("Zero AI - Pengaturan"));
        this.parent = parent;
        this.provider = ZeroConfig.PROVIDER.get();
    }

    @Override
    protected void init() {
        int cx = width / 2 - 100;
        int y = Math.max(20, height / 2 - 126);
        keyBox = null; urlBox = null;

        addRenderableWidget(CycleButton.builder((Provider p) -> Component.literal("Provider: " + p.name()))
                .withValues(Provider.values()).withInitialValue(provider)
                .create(cx, y, 200, 20, Component.literal("Provider"), (b, v) -> {
                    saveFields();
                    provider = v;
                    ZeroConfig.PROVIDER.set(v);
                    fetched = List.of(); fetchIdx = -1; status = "";
                    rebuildWidgets();
                }));
        y += 22;

        modelBox = new EditBox(font, cx, y, 200, 20, Component.literal("Model"));
        modelBox.setMaxLength(128);
        modelBox.setHint(Component.literal("Nama model"));
        modelBox.setValue(ZeroConfig.modelFor(provider));
        addRenderableWidget(modelBox);
        y += 22;

        addRenderableWidget(Button.builder(Component.literal("Ambil daftar model"), b -> {
            saveFields();
            status = "Mengambil daftar model...";
            AiClient.listModels().whenComplete((list, err) -> Minecraft.getInstance().execute(() -> {
                if (err != null) {
                    Throwable t = err; while (t.getCause() != null) t = t.getCause();
                    status = "Gagal: " + t.getMessage();
                } else {
                    fetched = list; fetchIdx = -1;
                    status = list.size() + " model ditemukan. Klik 'Model >' untuk memilih.";
                }
            }));
        }).bounds(cx, y, 130, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Model >"), b -> {
            if (fetched.isEmpty()) { status = "Ambil daftar model dulu."; return; }
            fetchIdx = (fetchIdx + 1) % fetched.size();
            modelBox.setValue(fetched.get(fetchIdx));
            status = (fetchIdx + 1) + "/" + fetched.size();
        }).bounds(cx + 134, y, 66, 20).build());
        y += 22;

        if (provider == Provider.OLLAMA) {
            urlBox = new EditBox(font, cx, y, 200, 20, Component.literal("URL"));
            urlBox.setMaxLength(256);
            urlBox.setHint(Component.literal("Server Ollama, mis. http://192.168.1.5:11434"));
            urlBox.setValue(ZeroConfig.OLLAMA_URL.get());
            addRenderableWidget(urlBox);
        } else {
            keyBox = new EditBox(font, cx, y, 200, 20, Component.literal("API Key"));
            keyBox.setMaxLength(256);
            keyBox.setHint(Component.literal("API Key " + provider.name()));
            keyBox.setFormatter((s, i) -> FormattedCharSequence.forward("\u2022".repeat(s.length()), Style.EMPTY));
            keyBox.setValue(ZeroConfig.keyFor(provider));
            addRenderableWidget(keyBox);
        }
        y += 22;

        langBox = new EditBox(font, cx, y, 200, 20, Component.literal("Bahasa"));
        langBox.setMaxLength(40);
        langBox.setHint(Component.literal("Bahasa jawaban"));
        langBox.setValue(ZeroConfig.LANGUAGE.get());
        addRenderableWidget(langBox);
        y += 22;

        addRenderableWidget(CycleButton.onOffBuilder(ZeroConfig.TTS_ENABLED.get())
                .create(cx, y, 200, 20, Component.literal("Suara TTS"), (b, v) -> ZeroConfig.TTS_ENABLED.set(v)));
        y += 22;
        addRenderableWidget(CycleButton.builder((TtsMode m) -> Component.literal("Mesin TTS: " + (m == TtsMode.SYSTEM ? "Sistem (robot)" : "OpenAI")))
                .withValues(TtsMode.values()).withInitialValue(ZeroConfig.TTS_MODE.get())
                .create(cx, y, 200, 20, Component.literal("TTS"), (b, v) -> ZeroConfig.TTS_MODE.set(v)));
        y += 22;
        addRenderableWidget(CycleButton.onOffBuilder(ZeroConfig.ALLOW_COMMANDS.get())
                .create(cx, y, 200, 20, Component.literal("AI boleh jalanin command"), (b, v) -> ZeroConfig.ALLOW_COMMANDS.set(v)));
        y += 22;
        addRenderableWidget(CycleButton.onOffBuilder(ZeroConfig.ALLOW_BUILD.get())
                .create(cx, y, 200, 20, Component.literal("AI boleh membangun"), (b, v) -> ZeroConfig.ALLOW_BUILD.set(v)));
        y += 22;
        addRenderableWidget(CycleButton.onOffBuilder(ZeroConfig.MUSIC_ENABLED.get())
                .create(cx, y, 200, 20, Component.literal("Musik robot"), (b, v) -> ZeroConfig.MUSIC_ENABLED.set(v)));
        y += 22;
        addRenderableWidget(Button.builder(Component.literal("Simpan & Tutup"), b -> onClose()).bounds(cx, y, 200, 20).build());
    }

    private void saveFields() {
        if (modelBox != null) ZeroConfig.setModel(provider, modelBox.getValue().trim());
        if (keyBox != null) ZeroConfig.setKey(provider, keyBox.getValue().trim());
        if (urlBox != null) ZeroConfig.OLLAMA_URL.set(urlBox.getValue().trim());
        if (langBox != null) ZeroConfig.LANGUAGE.set(langBox.getValue().trim());
    }

    @Override
    public void onClose() {
        saveFields();
        ZeroConfig.PROVIDER.set(provider);
        ZeroConfig.save();
        Minecraft.getInstance().setScreen(parent);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        super.render(g, mx, my, pt);
        g.drawCenteredString(font, title, width / 2, Math.max(6, height / 2 - 142), 0xFFFFFF);
        if (!status.isEmpty()) g.drawCenteredString(font, status, width / 2, height - 14, 0xAAAAAA);
    }
}
