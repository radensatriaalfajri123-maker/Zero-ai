package com.zeroai.client;

import com.zeroai.ZeroConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.arguments.blocks.BlockStateParser;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.*;
import java.util.regex.Pattern;

/** Menerjemahkan denah bangunan dari AI (DSL ringkas) menjadi perintah /fill dan /setblock secara bertahap. */
public final class ZeroBuilder {
    private static final Pattern BLOCK = Pattern.compile("^[a-z0-9_.\\-]+(:[a-z0-9_./\\-]+)?(\\[[a-z0-9_=,.\\-]+\\])?$");
    private static final Set<String> DENY = Set.of("command_block", "chain_command_block", "repeating_command_block",
            "structure_block", "structure_void", "jigsaw", "test_block", "test_instance_block");
    private static final String[] COMP = {"north", "east", "south", "west"};
    private static final int MAX_CMDS = 2000, MAX_UNDO_VOL = 80000;
    private static final long MAX_BLOCKS = 250000;

    private static final Deque<String> queue = new ArrayDeque<>();
    private static List<String> undoCmds;
    private static boolean active;
    private static int total, done;
    private static String title = "";

    public static boolean isBuilding() { return active; }
    public static String status() { return "\u00a76Membangun " + title + " \u00a7f" + done + "/" + total + " \u00a77(ketik 'stop' untuk berhenti)"; }

    // ------------------------------------------------------------ rencana
    private interface Pred { boolean in(int dx, int dy, int dz); }

    private static final class Plan {
        final BlockPos origin; final int fx, fz, rx, rz, fi;
        final List<String> cmds = new ArrayList<>();
        long blocks;
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;

        Plan(BlockPos o, Direction f) {
            origin = o; fx = f.getStepX(); fz = f.getStepZ(); rx = -fz; rz = fx;
            fi = switch (f) { case NORTH -> 0; case EAST -> 1; case SOUTH -> 2; default -> 3; };
        }
        BlockPos w(int x, int y, int z) { return new BlockPos(origin.getX() + x * rx + z * fx, origin.getY() + y, origin.getZ() + x * rz + z * fz); }
        void track(BlockPos p) {
            minX = Math.min(minX, p.getX()); maxX = Math.max(maxX, p.getX());
            minY = Math.min(minY, p.getY()); maxY = Math.max(maxY, p.getY());
            minZ = Math.min(minZ, p.getZ()); maxZ = Math.max(maxZ, p.getZ());
        }
        boolean full() { return cmds.size() > MAX_CMDS || blocks > MAX_BLOCKS; }

        void fill(BlockPos a, BlockPos b, String blk, String mode) {
            int x1 = Math.min(a.getX(), b.getX()), x2 = Math.max(a.getX(), b.getX());
            int y1 = Math.min(a.getY(), b.getY()), y2 = Math.max(a.getY(), b.getY());
            int z1 = Math.min(a.getZ(), b.getZ()), z2 = Math.max(a.getZ(), b.getZ());
            long area = (long) (x2 - x1 + 1) * (z2 - z1 + 1), vol = area * (y2 - y1 + 1);
            if (area > 32768 || (!mode.isEmpty() && vol > 32768)) throw new IllegalArgumentException("area terlalu besar");
            int step = (int) Math.max(1, 32768 / area);
            for (int y = y1; y <= y2; y += step) {
                int ye = Math.min(y2, y + step - 1);
                cmds.add("fill " + x1 + " " + y + " " + z1 + " " + x2 + " " + ye + " " + z2 + " " + blk + (mode.isEmpty() ? "" : " " + mode));
            }
            blocks += vol; track(a); track(b);
            if (full()) throw new IllegalArgumentException("bangunan terlalu besar");
        }
        void set(BlockPos p, String blk) {
            cmds.add("setblock " + p.getX() + " " + p.getY() + " " + p.getZ() + " " + blk);
            blocks++; track(p);
            if (full()) throw new IllegalArgumentException("bangunan terlalu besar");
        }
        String rot(String b) {
            int i = b.indexOf('[');
            if (i < 0 || fi == 0 && false) return b;
            StringBuilder sb = new StringBuilder();
            for (String kv : b.substring(i + 1, b.length() - 1).split(",")) {
                String[] p = kv.split("=", 2);
                if (p.length < 2) continue;
                String k = p[0], v = p[1];
                int ki = idx(k), vi = idx(v);
                if (k.equals("facing") && vi >= 0) v = COMP[(vi + fi) % 4];
                else if (ki >= 0) k = COMP[(ki + fi) % 4];
                else if (k.equals("axis") && fi % 2 == 1) v = v.equals("x") ? "z" : v.equals("z") ? "x" : v;
                if (sb.length() > 0) sb.append(',');
                sb.append(k).append('=').append(v);
            }
            return b.substring(0, i) + "[" + sb + "]";
        }
        static int idx(String s) { for (int i = 0; i < 4; i++) if (COMP[i].equals(s)) return i; return -1; }
    }

    private static String block(Plan P, String raw) {
        String b = raw.toLowerCase(Locale.ROOT);
        if (!BLOCK.matcher(b).matches()) throw new IllegalArgumentException("blok tidak valid: " + raw);
        if (!b.contains(":") || (b.indexOf('[') >= 0 && b.indexOf(':') > b.indexOf('['))) b = "minecraft:" + b;
        String id = b.contains("[") ? b.substring(0, b.indexOf('[')) : b;
        if (DENY.contains(id.substring(id.indexOf(':') + 1))) throw new IllegalArgumentException("blok dilarang: " + id);
        return P.rot(b);
    }

    private static int[] ints(String[] t, int from, int n) {
        if (t.length < from + n) throw new IllegalArgumentException("argumen kurang");
        int[] r = new int[n];
        for (int i = 0; i < n; i++) {
            try { r[i] = Integer.parseInt(t[from + i]); } catch (NumberFormatException e) { throw new IllegalArgumentException("angka salah: " + t[from + i]); }
            if (Math.abs(r[i]) > 200) throw new IllegalArgumentException("angka terlalu besar");
        }
        return r;
    }

    private static void raster(Plan P, int cx, int cz, int rr, int ymin, int ymax, int cy, Pred pr, String blk) {
        for (int y = ymin; y <= ymax; y++) {
            for (int z = cz - rr; z <= cz + rr; z++) {
                int start = Integer.MIN_VALUE;
                for (int x = cx - rr; x <= cx + rr + 1; x++) {
                    boolean in = x <= cx + rr && pr.in(x - cx, y - cy, z - cz);
                    if (in && start == Integer.MIN_VALUE) start = x;
                    else if (!in && start != Integer.MIN_VALUE) { P.fill(P.w(start, y, z), P.w(x - 1, y, z), blk, ""); start = Integer.MIN_VALUE; }
                }
            }
        }
    }

    private static void parseLine(Plan P, String line) {
        String[] t = line.trim().split("\\s+");
        String verb = t[0].toLowerCase(Locale.ROOT);
        switch (verb) {
            case "box", "hollow", "outline" -> {
                int[] n = ints(t, 1, 6); if (t.length < 8) throw new IllegalArgumentException("blok kurang");
                P.fill(P.w(n[0], n[1], n[2]), P.w(n[3], n[4], n[5]), block(P, t[7]), verb.equals("box") ? "" : verb);
            }
            case "clear" -> { int[] n = ints(t, 1, 6); P.fill(P.w(n[0], n[1], n[2]), P.w(n[3], n[4], n[5]), "minecraft:air", ""); }
            case "set" -> { int[] n = ints(t, 1, 3); if (t.length < 5) throw new IllegalArgumentException("blok kurang"); P.set(P.w(n[0], n[1], n[2]), block(P, t[4])); }
            case "line" -> {
                int[] n = ints(t, 1, 6); if (t.length < 8) throw new IllegalArgumentException("blok kurang");
                String b = block(P, t[7]);
                int steps = Math.max(Math.abs(n[3] - n[0]), Math.max(Math.abs(n[4] - n[1]), Math.abs(n[5] - n[2])));
                for (int i = 0; i <= steps; i++) {
                    double f = steps == 0 ? 0 : (double) i / steps;
                    P.set(P.w((int) Math.round(n[0] + (n[3] - n[0]) * f), (int) Math.round(n[1] + (n[4] - n[1]) * f), (int) Math.round(n[2] + (n[5] - n[2]) * f)), b);
                }
            }
            case "cyl", "hcyl" -> {
                int[] n = ints(t, 1, 5); if (t.length < 7) throw new IllegalArgumentException("blok kurang");
                int cx = n[0], y = n[1], cz = n[2], r = Math.min(40, Math.max(1, n[3])), h = Math.min(80, Math.max(1, n[4]));
                boolean hollow = verb.equals("hcyl") && r >= 2;
                raster(P, cx, cz, r, y, y + h - 1, y, (dx, dy, dz) -> {
                    int d = dx * dx + dz * dz;
                    return d <= r * r + r && !(hollow && d <= (r - 1) * (r - 1) + (r - 1));
                }, block(P, t[6]));
            }
            case "sphere", "hsphere", "dome" -> {
                int[] n = ints(t, 1, 4); if (t.length < 6) throw new IllegalArgumentException("blok kurang");
                int cx = n[0], cy = n[1], cz = n[2], r = Math.min(40, Math.max(1, n[3]));
                boolean hollow = !verb.equals("sphere") && r >= 2, half = verb.equals("dome");
                raster(P, cx, cz, r, half ? cy : cy - r, cy + r, cy, (dx, dy, dz) -> {
                    int d = dx * dx + dy * dy + dz * dz;
                    return d <= r * r + r && !(hollow && d <= (r - 1) * (r - 1) + (r - 1));
                }, block(P, t[5]));
            }
            case "pyramid" -> {
                int[] n = ints(t, 1, 4); if (t.length < 6) throw new IllegalArgumentException("blok kurang");
                String b = block(P, t[5]); int r = Math.min(40, Math.max(0, n[3]));
                for (int k = 0; k <= r; k++) { int half = r - k; P.fill(P.w(n[0] - half, n[1] + k, n[2] - half), P.w(n[0] + half, n[1] + k, n[2] + half), b, ""); }
            }
            default -> throw new IllegalArgumentException("perintah tidak dikenal: " + verb);
        }
    }

    // ------------------------------------------------------------ jalankan
    public static void start(List<String> dsl, String ttl) {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.level == null) return;
        if (active) { ZeroBrain.sys("\u00a7e[Zero AI] Aku masih membangun. Ketik 'stop' dulu."); return; }
        Direction f = p.getDirection();
        Plan P = new Plan(p.blockPosition().relative(f, 3), f);
        List<String> errs = new ArrayList<>();
        int n = 0;
        for (String l : dsl) {
            n++;
            try { parseLine(P, l); }
            catch (IllegalArgumentException e) { errs.add("baris " + n + ": " + e.getMessage()); if (P.full()) break; }
            catch (RuntimeException e) { errs.add("baris " + n + ": error"); }
        }
        if (P.cmds.isEmpty()) {
            ZeroBrain.sys("\u00a7c[Zero AI] Denah gagal dibaca" + (errs.isEmpty() ? "." : ": " + errs.get(0)));
            return;
        }
        undoCmds = snapshot(P, mc.level);
        queue.clear(); queue.addAll(P.cmds);
        total = P.cmds.size(); done = 0; title = (ttl == null || ttl.isBlank()) ? "bangunan" : ttl; active = true;
        ZeroBrain.sys("\u00a76[Zero AI] Mulai membangun '" + title + "': " + total + " perintah, sekitar " + P.blocks + " blok."
                + (errs.isEmpty() ? "" : " \u00a77(" + errs.size() + " baris dilewati: " + errs.get(0) + ")")
                + (undoCmds == null ? " \u00a77(undo tidak tersedia, area terlalu besar)" : ""));
    }

    private static List<String> snapshot(Plan P, Level lvl) {
        if (P.minX > P.maxX) return null;
        long vol = (long) (P.maxX - P.minX + 1) * (P.maxY - P.minY + 1) * (P.maxZ - P.minZ + 1);
        if (vol > MAX_UNDO_VOL) return null;
        List<String> out = new ArrayList<>();
        for (int y = P.minY; y <= P.maxY; y++) for (int z = P.minZ; z <= P.maxZ; z++) {
            BlockState prev = null; int start = 0;
            for (int x = P.minX; x <= P.maxX + 1; x++) {
                BlockState s = x <= P.maxX ? lvl.getBlockState(new BlockPos(x, y, z)) : null;
                if (s != prev) {
                    if (prev != null) out.add("fill " + start + " " + y + " " + z + " " + (x - 1) + " " + y + " " + z + " " + BlockStateParser.serialize(prev));
                    prev = s; start = x;
                }
            }
            if (out.size() > 4000) return null;
        }
        return out;
    }

    public static void tick() {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) { queue.clear(); active = false; return; }
        int per = ZeroConfig.BUILD_SPEED.get();
        for (int i = 0; i < per && !queue.isEmpty(); i++) { mc.player.connection.sendCommand(queue.poll()); done++; }
        ZeroClientState.setAction("build", 1500);
        if (mc.player.tickCount % 4 == 0) ZeroMusic.beep(6 + (done * 7) % 14);
        if (queue.isEmpty()) {
            active = false; ZeroClientState.clearAction();
            ZeroBrain.sys("\u00a7a[Zero AI] Selesai: " + title + "! (ketik 'undo' untuk mengembalikan)");
            ZeroTts.speak("Selesai! " + title + " sudah jadi.");
        }
    }

    public static void cancel() {
        if (!active) { ZeroBrain.sys("\u00a77Zero tidak sedang membangun."); return; }
        queue.clear(); active = false; ZeroClientState.clearAction();
        ZeroBrain.sys("\u00a7e[Zero AI] Pembangunan dihentikan. Ketik 'undo' untuk mengembalikan area.");
    }

    public static void undo() {
        if (active) { queue.clear(); active = false; ZeroClientState.clearAction(); }
        if (undoCmds == null || undoCmds.isEmpty()) { ZeroBrain.sys("\u00a77Tidak ada bangunan yang bisa di-undo."); return; }
        queue.clear(); queue.addAll(undoCmds); total = undoCmds.size(); done = 0; title = "pengembalian area"; active = true;
        undoCmds = null;
        ZeroBrain.sys("\u00a76[Zero AI] Mengembalikan area seperti semula (isi peti tidak ikut kembali).");
    }
}
