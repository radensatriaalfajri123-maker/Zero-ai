package com.zeroai.client;

import com.zeroai.ZeroMod;
import com.zeroai.entity.ZeroEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.model.data.EntityModelData;

public class ZeroGeoModel extends GeoModel<ZeroEntity> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(ZeroMod.MODID, "geo/zero.geo.json");
    private static final ResourceLocation ANIM = ResourceLocation.fromNamespaceAndPath(ZeroMod.MODID, "animations/zero.animation.json");
    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath(ZeroMod.MODID, "textures/entity/zero.png");
    private static final ResourceLocation TEX_M = ResourceLocation.fromNamespaceAndPath(ZeroMod.MODID, "textures/entity/zero_monster.png");

    @Override public ResourceLocation getModelResource(ZeroEntity e) { return MODEL; }
    @Override public ResourceLocation getTextureResource(ZeroEntity e) { return e.isMonsterMode() || e.isGiant() ? TEX_M : TEX; }
    @Override public ResourceLocation getAnimationResource(ZeroEntity e) { return ANIM; }

    @Override
    public void setCustomAnimations(ZeroEntity a, long id, AnimationState<ZeroEntity> st) {
        GeoBone head = getAnimationProcessor().getBone("head");
        if (head == null) return;
        EntityModelData d = st.getData(DataTickets.ENTITY_MODEL_DATA);
        head.setRotX(head.getRotX() + d.headPitch() * Mth.DEG_TO_RAD * 0.8f);
        head.setRotY(head.getRotY() + d.netHeadYaw() * Mth.DEG_TO_RAD * 0.8f);
    }
}
