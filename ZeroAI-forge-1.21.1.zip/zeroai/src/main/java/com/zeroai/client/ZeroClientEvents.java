package com.zeroai.client;

import com.zeroai.ZeroMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Mod.EventBusSubscriber(modid = ZeroMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ZeroClientEvents {
    private static final Pattern ASK = Pattern.compile("^@?zero[,:!]?\\s+(.+)$", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    @SubscribeEvent
    public static void onChat(ClientChatEvent e) {
        Matcher m = ASK.matcher(e.getMessage());
        if (m.matches()) {
            e.setCanceled(true);
            String t = m.group(1).trim();
            ZeroBrain.sys("§7[Kamu] §f" + t);
            ZeroBrain.ask(t);
        }
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            if (MicRecorder.isRecording()) MicRecorder.stop();
            return;
        }
        ZeroClientState.tick();
        ZeroMusic.tick();
        while (ZeroKeys.CONFIG.consumeClick()) mc.setScreen(new ConfigScreen(null));

        boolean down = ZeroKeys.TALK.isDown() && mc.screen == null;
        if (down && !MicRecorder.isRecording()) {
            ZeroTts.stop();
            if (!MicRecorder.start()) ZeroBrain.sys("§c[Zero AI] Mic tidak bisa dibuka (cek izin mikrofon).");
        } else if (!down && MicRecorder.isRecording()) {
            byte[] wav = MicRecorder.stop();
            if (wav == null) ZeroBrain.sys("§7(rekaman terlalu pendek)");
            else ZeroBrain.listen(wav);
        }
    }

    @SubscribeEvent
    public static void onHud(RenderGuiEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        GuiGraphics g = e.getGuiGraphics();
        Font f = mc.font;
        int w = g.guiWidth();
        if (MicRecorder.isRecording()) g.drawCenteredString(f, "\u25CF MENDENGARKAN... (lepas G untuk kirim)", w / 2, 24, 0xFF5555);
        else if (ZeroBrain.isThinking()) g.drawCenteredString(f, "Zero sedang berpikir...", w / 2, 24, 0x55FFFF);

        var z = ZeroClientState.cached;
        if (z != null) {
            int mood = z.getMood();
            boolean mon = z.isMonsterMode();
            int color = mood >= 60 ? 0xFF55FF55 : mood >= 30 ? 0xFFFFFF55 : 0xFFFF4444;
            int x = 6, y = 6, bw = 90;
            g.drawString(f, mon ? "\u2620 ZERO AI - MONSTER!" : "ZERO AI", x, y, mon ? 0xFF5555 : 0x55FFFF, true);
            g.fill(x - 1, y + 11, x + bw + 1, y + 21, 0xFF000000);
            g.fill(x, y + 12, x + bw, y + 20, 0xFF333333);
            g.fill(x, y + 12, x + bw * mood / 100, y + 20, color);
            g.drawString(f, "Mood " + mood + "%", x + bw + 6, y + 12, 0xFFFFFF, true);
        }
    }
}
