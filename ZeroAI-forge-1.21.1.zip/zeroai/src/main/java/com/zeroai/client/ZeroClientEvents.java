package com.zeroai.client;

import com.zeroai.ZeroMod;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Mod.EventBusSubscriber(modid = ZeroMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ZeroClientEvents {
    private static int hudTick;
    private static final Pattern ASK = Pattern.compile("^@?zero[,:!]?\\s+(.+)$", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    @SubscribeEvent
    public static void onChat(ClientChatEvent e) {
        Matcher m = ASK.matcher(e.getMessage());
        if (m.matches()) {
            e.setCanceled(true);
            String t = m.group(1).trim();
            ZeroBrain.sys("§7[Kamu] §f" + t);
            ZeroBrain.ask(t);
        }
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            if (MicRecorder.isRecording()) MicRecorder.stop();
            return;
        }
        ZeroClientState.tick();
        ZeroMusic.tick();
        while (ZeroKeys.CONFIG.consumeClick()) mc.setScreen(new ConfigScreen(null));

        boolean down = ZeroKeys.TALK.isDown() && mc.screen == null;
        if (down && !MicRecorder.isRecording()) {
            ZeroTts.stop();
            if (!MicRecorder.start()) ZeroBrain.sys("§c[Zero AI] Mic tidak bisa dibuka (cek izin mikrofon).");
        } else if (!down && MicRecorder.isRecording()) {
            byte[] wav = MicRecorder.stop();
            if (wav == null) ZeroBrain.sys("§7(rekaman terlalu pendek)");
            else ZeroBrain.listen(wav);
        }

        hudTick++;
        if (hudTick % 5 == 0) {
            var z = ZeroClientState.cached;
            String txt = null;
            if (MicRecorder.isRecording()) txt = "\u00a7c\u25CF MENDENGARKAN... (lepas G untuk kirim)";
            else if (ZeroBrain.isThinking()) txt = "\u00a7bZero sedang berpikir...";
            else if (z != null) {
                int mood = z.getMood();
                String c = mood >= 60 ? "\u00a7a" : mood >= 30 ? "\u00a7e" : "\u00a7c";
                String bar = "\u2588".repeat(mood / 10) + "\u2591".repeat(10 - mood / 10);
                txt = (z.isMonsterMode() ? "\u00a74\u2620 ZERO AI MONSTER " : "\u00a7bZERO AI ") + c + bar + " \u00a7f" + mood + "%";
            }
            if (txt != null) mc.gui.setOverlayMessage(Component.literal(txt), false);
        }
    }
}
