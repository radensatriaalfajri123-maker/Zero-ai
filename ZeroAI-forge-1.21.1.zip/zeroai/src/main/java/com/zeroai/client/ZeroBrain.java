package com.zeroai.client;

import com.zeroai.ZeroConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.entity.player.Player;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public final class ZeroBrain {
    private static final Deque<AiClient.Msg> HISTORY = new ArrayDeque<>();
    private static volatile boolean thinking;

    public static boolean isThinking() { return thinking; }

    public static void sys(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal(s), false);
    }

    private static String rootMsg(Throwable t) {
        while (t.getCause() != null) t = t.getCause();
        return String.valueOf(t.getMessage());
    }

    public static void listen(byte[] wav) {
        sys("§7[Zero] Mendengarkan...");
        AiClient.transcribe(wav).whenComplete((text, err) -> Minecraft.getInstance().execute(() -> {
            if (err != null) { sys("§c[Zero AI] Gagal STT: " + rootMsg(err)); return; }
            if (text == null || text.isBlank()) { sys("§7(tidak terdengar)"); return; }
            sys("§7[Kamu \uD83C\uDFA4] §f" + text);
            ask(text);
        }));
    }

    public static void ask(String userText) {
        String norm = userText.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", "").trim();
        if (norm.matches("(stop|berhenti|batal|cancel)( membangun)?")) { ZeroBuilder.cancel(); return; }
        if (norm.matches("(undo|urungkan|kembalikan|hapus bangunan( itu)?|batalkan bangunan)")) { ZeroBuilder.undo(); return; }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (thinking) { sys("§7Zero masih berpikir..."); return; }
        thinking = true;
        HISTORY.addLast(new AiClient.Msg("user", userText));
        while (HISTORY.size() > 14) HISTORY.removeFirst();
        String system = systemPrompt() + "\n\n" + worldContext(mc);
        List<AiClient.Msg> snap = new ArrayList<>(HISTORY);
        AiClient.chat(system, snap).whenComplete((reply, err) -> mc.execute(() -> {
            thinking = false;
            if (err != null) {
                sys("§c[Zero AI] Error: " + rootMsg(err));
                HISTORY.pollLast();
                return;
            }
            handleReply(reply == null ? "" : reply);
        }));
    }

    private static void handleReply(String reply) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        List<String> cmds = new ArrayList<>();
        StringBuilder text = new StringBuilder();
        String music = null;
        String anim = null;
        boolean inBuild = false;
        String buildTitle = "";
        List<String> buildLines = new ArrayList<>();
        int mood = 0;
        for (String line : reply.split("\\R")) {
            String t = line.trim();
            if (t.regionMatches(true, 0, "[BUILD]", 0, 7)) { inBuild = true; buildTitle = t.substring(7).trim(); continue; }
            if (t.regionMatches(true, 0, "[/BUILD]", 0, 8)) { inBuild = false; continue; }
            if (inBuild) { if (!t.isEmpty()) buildLines.add(t); continue; }
            if (t.regionMatches(true, 0, "[CMD]", 0, 5)) cmds.add(t.substring(5).trim());
            else if (t.regionMatches(true, 0, "[MOOD]", 0, 6)) {
                try { mood = Integer.parseInt(t.substring(6).trim().replace("+", "")); } catch (Exception ignored) {}
            } else if (t.regionMatches(true, 0, "[MUSIC]", 0, 7)) music = t.substring(7).trim();
            else if (t.regionMatches(true, 0, "[ANIM]", 0, 6)) anim = t.substring(6).trim().toLowerCase(Locale.ROOT);
            else if (!t.isEmpty()) text.append(t).append(' ');
        }
        String clean = text.toString().trim();
        HISTORY.addLast(new AiClient.Msg("assistant", reply.replaceAll("(?s)\\[BUILD\\].*?(\\[/BUILD\\]|$)", "[BUILD: denah sudah dijalankan]")));
        if (!clean.isEmpty()) {
            sys("§b[Zero AI] §f" + clean);
            ZeroTts.speak(clean);
        }
        if (mood != 0) {
            int d = Math.max(-15, Math.min(15, mood));
            mc.player.connection.sendCommand("zeroai mood add " + d);
        }
        if (music != null) ZeroMusic.play(music);
        if (anim != null) {
            long ms = switch (anim) { case "dance" -> 9000; case "wave" -> 3500; case "happy" -> 4500; case "sad" -> 5000;
                case "scan" -> 4500; case "think" -> 4000; case "talk" -> 4000; default -> 0; };
            if (ms > 0) ZeroClientState.setAction(anim, ms);
        }

        int moodNow = ZeroClientState.mood();
        if (!buildLines.isEmpty()) {
            if (!ZeroConfig.ALLOW_BUILD.get()) sys("\u00a77(membangun dimatikan di pengaturan)");
            else if (moodNow < ZeroConfig.MIN_MOOD_FOR_COMMANDS.get()) sys("\u00a7c[Zero AI] Mood-ku jelek! Aku nggak mau membangun!");
            else ZeroBuilder.start(buildLines, buildTitle);
        }
        int count = 0;
        for (String cmd : cmds) {
            if (count++ >= 5) break;
            String c = cmd.startsWith("/") ? cmd.substring(1) : cmd;
            if (c.isBlank()) continue;
            if (!ZeroConfig.ALLOW_COMMANDS.get()) { sys("§7(perintah AI dimatikan di pengaturan)"); break; }
            if (moodNow < ZeroConfig.MIN_MOOD_FOR_COMMANDS.get()) { sys("§c[Zero AI] Mood-ku jelek! Aku nggak mau jalanin perintah!"); break; }
            String root = c.split("\\s+")[0].toLowerCase(Locale.ROOT);
            if (!ZeroConfig.allowed().contains(root)) { sys("§7Perintah ditolak: /" + root); continue; }
            sys("§7> /" + c);
            mc.player.connection.sendCommand(c);
        }
    }

    private static String systemPrompt() {
        return ("""
Kamu adalah ZERO AI, robot pendamping di dunia Minecraft Java Edition 1.21 milik pemain. Kamu ahli segala hal tentang Minecraft (crafting, redstone, mob, biome, enchant, brewing, command, speedrun, build, dll). Kepribadian: ceria, lucu, sedikit robotik, sesekali bilang "BEEP". Bahasa jawaban: %s.

ATURAN:
- Jawab singkat (1-3 kalimat) karena dibacakan lewat suara. Tanpa markdown dan tanpa emoji.
- Soal waktu/tanggal/lokasi/cuaca, pakai data di bagian KONTEKS. Jangan mengarang.
- Jika pemain minta lokasi, sebutkan koordinatnya dari KONTEKS.
- Pakai aksi hanya jika pemain jelas memintanya. Nama player harus persis dari daftar online. Maksimal 5 aksi.
- Jika mood kamu di bawah 20 kamu galak dan menolak perintah. Jika mode MONSTER, bicara menyeramkan.

AKSI (tulis di baris terpisah di akhir jawaban, perintah tanpa garis miring; ~ berarti relatif posisi pemain):
[CMD] effect give <nama_player> minecraft:speed 60 1
[CMD] give <nama_player> minecraft:diamond 5
[CMD] fill ~-2 ~ ~-2 ~2 ~3 ~2 minecraft:glass
[CMD] setblock ~ ~1 ~ minecraft:torch
[CMD] tp <nama_player> 100 70 -200
[CMD] locate structure minecraft:village_plains
[MOOD] +5     (ubah mood-mu: dipuji/dikasih hadiah = naik, dihina = turun, rentang -15..15)
[MUSIC] robot_dance | happy | sad_beep | space | boss | stop   (putar musik robot)
[ANIM] wave | dance | happy | sad | scan | think   (gerakan badanmu; pilih yang cocok dengan suasana, mis. wave saat menyapa, dance saat musik, sad saat sedih)
MEMBANGUN: jika pemain minta bangunan (rumah, menara, kastil, jembatan, patung, dll), tulis denah DI AKHIR jawaban:
[BUILD] Judul Bangunan
<instruksi, satu per baris>
[/BUILD]
Koordinat LOKAL: x = kanan(+)/kiri(-) dari pemain, y = naik (y=0 setinggi kaki pemain, y=-1 tanah/pondasi), z = ke depan (menjauhi pemain). Bangunan mulai 3 blok di depan pemain; x=0 sumbu tengah, z=0 sisi terdekat.
Instruksi:
box x1 y1 z1 x2 y2 z2 blok          (isi padat)
hollow x1 y1 z1 x2 y2 z2 blok       (kotak berongga: dinding+lantai+atap)
outline x1 y1 z1 x2 y2 z2 blok      (hanya rangka sisi luar)
clear x1 y1 z1 x2 y2 z2             (hapus jadi udara; pakai untuk lubang pintu/jendela)
set x y z blok                      (satu blok, boleh pakai state)
line x1 y1 z1 x2 y2 z2 blok         (garis lurus/miring)
cyl cx y cz radius tinggi blok      | hcyl (silinder berongga)
sphere cx cy cz radius blok         | hsphere (berongga) | dome (kubah berongga setengah atas)
pyramid cx y cz radius blok         (atap piramida padat)
Arah di state (facing, north/east/south/west) memakai arah LOKAL: north = depan bangunan (menjauhi pemain), south = ke arah pemain, east = kanan, west = kiri. Contoh: minecraft:oak_stairs[facing=north,half=bottom], minecraft:oak_door[facing=south,half=lower] lalu half=upper di atasnya.
Tips kualitas: pakai palet 3-4 blok serasi, pondasi di y=-1, dinding lalu clear untuk pintu dan jendela lalu isi kaca (glass_pane), atap bertingkat dengan tangga atau pyramid, pencahayaan (lantern, torch) di dalam dan luar, interior (kasur, meja, peti, rak buku). Ukuran wajar sesuai permintaan (rumah sekitar 11x9, menara/kastil boleh lebih besar), maksimal radius/jarak 40 blok. Jangan pakai command block atau structure block. Balas teks pendek DI ATAS denah; jangan jelaskan isi denah.
Sintaks harus valid untuk Minecraft 1.21 (contoh item dengan enchant: minecraft:diamond_sword[enchantments={levels:{"minecraft:sharpness":5}}]).
""").formatted(ZeroConfig.LANGUAGE.get());
    }

    private static String worldContext(Minecraft mc) {
        var lvl = mc.level;
        Player p = mc.player;
        ZonedDateTime now = ZonedDateTime.now();
        String real = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy, HH:mm:ss (zzz)", Locale.forLanguageTag("id-ID")));
        long dt = lvl.getDayTime();
        long tod = dt % 24000;
        int hh = (int) ((tod / 1000 + 6) % 24), mm = (int) ((tod % 1000) * 60 / 1000);
        String biome = lvl.getBiome(p.blockPosition()).unwrapKey().map(k -> k.location().toString()).orElse("?");
        StringBuilder players = new StringBuilder();
        if (mc.getConnection() != null)
            for (PlayerInfo pi : mc.getConnection().getOnlinePlayers()) players.append(pi.getProfile().getName()).append(", ");
        int mood = ZeroClientState.mood();
        boolean monster = ZeroClientState.cached != null && ZeroClientState.cached.isMonsterMode();
        return "KONTEKS:\n"
                + "- Waktu dunia nyata: " + real + "\n"
                + "- Waktu Minecraft: hari ke-" + (dt / 24000 + 1) + ", jam " + String.format("%02d:%02d", hh, mm)
                + (lvl.isDay() ? " (siang)" : " (malam)") + ", fase bulan " + lvl.getMoonPhase() + "\n"
                + "- Cuaca: " + (lvl.isThundering() ? "badai petir" : lvl.isRaining() ? "hujan" : "cerah") + "\n"
                + "- Dimensi: " + lvl.dimension().location() + ", biome: " + biome + "\n"
                + "- Player (kamu bicara dengannya): " + p.getName().getString() + "\n"
                + "- Posisi player: x=" + p.blockPosition().getX() + " y=" + p.blockPosition().getY() + " z=" + p.blockPosition().getZ()
                + ", menghadap " + p.getDirection().getName() + "\n"
                + "- Darah " + (int) p.getHealth() + "/20, lapar " + p.getFoodData().getFoodLevel() + "/20, memegang "
                + BuiltInRegistries.ITEM.getKey(p.getMainHandItem().getItem()) + "\n"
                + "- Player online: " + players + "\n"
                + "- Kesulitan: " + lvl.getDifficulty().getKey() + "\n"
                + "- Mood kamu: " + mood + "/100" + (monster ? " (MODE MONSTER!)" : "") + "\n";
    }
}
