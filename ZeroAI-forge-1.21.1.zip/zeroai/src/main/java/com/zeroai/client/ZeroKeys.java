package com.zeroai.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public final class ZeroKeys {
    public static final KeyMapping TALK = new KeyMapping("key.zeroai.talk", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.zeroai");
    public static final KeyMapping CONFIG = new KeyMapping("key.zeroai.config", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.zeroai");
}
