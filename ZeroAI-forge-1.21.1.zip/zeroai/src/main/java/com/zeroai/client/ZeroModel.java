package com.zeroai.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.zeroai.ZeroMod;
import com.zeroai.entity.ZeroEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class ZeroModel extends EntityModel<ZeroEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(ZeroMod.MODID, "zero"), "main");
    private static final float RAD = 0.017453292F;
    private final ModelPart root, head, antenna, body, rightArm, leftArm, rightLeg, leftLeg;

    public ZeroModel(ModelPart root) {
        this.root = root;
        head = root.getChild("head");
        antenna = head.getChild("antenna");
        body = root.getChild("body");
        rightArm = root.getChild("right_arm");
        leftArm = root.getChild("left_arm");
        rightLeg = root.getChild("right_leg");
        leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4, -8, -4, 8, 8, 8), PartPose.offset(0, 10, 0));
        head.addOrReplaceChild("antenna", CubeListBuilder.create().texOffs(48, 0).addBox(-0.5f, -5, -0.5f, 1, 5, 1)
                .texOffs(56, 0).addBox(-1, -7, -1, 2, 2, 2), PartPose.offset(0, -8, 0));
        r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16).addBox(-4, -8, -2, 8, 8, 4), PartPose.offset(0, 18, 0));
        r.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(32, 16).addBox(-1, 0, -1, 2, 7, 2), PartPose.offset(-5, 11, 0));
        r.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(32, 16).addBox(-1, 0, -1, 2, 7, 2), PartPose.offset(5, 11, 0));
        r.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(0, 32).addBox(-1.5f, 0, -1.5f, 3, 6, 3), PartPose.offset(-2, 18, 0));
        r.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(0, 32).addBox(-1.5f, 0, -1.5f, 3, 6, 3), PartPose.offset(2, 18, 0));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(ZeroEntity e, float limbSwing, float limbAmt, float age, float yaw, float pitch) {
        boolean talking = ZeroClientState.isTalking(e);
        boolean monster = e.isMonsterMode();
        float sw = limbSwing * 0.6662f;

        head.x = 0; head.xRot = pitch * RAD; head.yRot = yaw * RAD; head.zRot = 0;
        body.xRot = 0;
        rightLeg.xRot = Mth.cos(sw) * 1.4f * limbAmt;
        leftLeg.xRot = Mth.cos(sw + Mth.PI) * 1.4f * limbAmt;
        float idle = Mth.sin(age * 0.067f) * 0.05f;
        rightArm.xRot = Mth.cos(sw + Mth.PI) * 1.1f * limbAmt + idle;
        leftArm.xRot = Mth.cos(sw) * 1.1f * limbAmt - idle;
        rightArm.zRot = 0.05f + Mth.cos(age * 0.09f) * 0.05f;
        leftArm.zRot = -0.05f - Mth.cos(age * 0.09f) * 0.05f;
        antenna.zRot = Mth.sin(age * 0.15f) * 0.25f;
        antenna.xRot = Mth.cos(age * 0.12f) * 0.15f;

        if (talking) {
            rightArm.xRot = -2.2f + Mth.sin(age * 0.7f) * 0.5f;
            rightArm.zRot = -0.3f;
            head.xRot += Mth.sin(age * 0.8f) * 0.12f;
            antenna.zRot = Mth.sin(age * 0.9f) * 0.5f;
        }
        if (monster) {
            rightArm.xRot = -1.6f + Mth.sin(age * 1.3f) * 0.25f;
            leftArm.xRot = -1.6f + Mth.cos(age * 1.3f) * 0.25f;
            head.zRot = Mth.sin(age * 2f) * 0.08f;
            head.xRot += 0.25f;
            head.x = Mth.sin(age * 3f) * 0.4f;
            body.xRot = 0.2f;
            antenna.zRot = Mth.sin(age * 2.5f) * 0.7f;
        }
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, int color) {
        root.render(ps, vc, light, overlay, color);
    }
}
