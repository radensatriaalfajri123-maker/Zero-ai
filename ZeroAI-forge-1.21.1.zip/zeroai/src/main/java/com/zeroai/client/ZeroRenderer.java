package com.zeroai.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.zeroai.ZeroMod;
import com.zeroai.entity.ZeroEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ZeroRenderer extends MobRenderer<ZeroEntity, ZeroModel> {
    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath(ZeroMod.MODID, "textures/entity/zero.png");
    private static final ResourceLocation TEX_M = ResourceLocation.fromNamespaceAndPath(ZeroMod.MODID, "textures/entity/zero_monster.png");

    public ZeroRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new ZeroModel(ctx.bakeLayer(ZeroModel.LAYER)), 0.4f);
    }
    @Override public ResourceLocation getTextureLocation(ZeroEntity e) { return e.isMonsterMode() ? TEX_M : TEX; }
    @Override protected void scale(ZeroEntity e, PoseStack ps, float pt) { if (e.isMonsterMode()) ps.scale(1.4f, 1.4f, 1.4f); }
}
