package com.zeroai.client;

import com.zeroai.entity.ZeroEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

public class ZeroRenderer extends GeoEntityRenderer<ZeroEntity> {
    public ZeroRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new ZeroGeoModel());
        this.shadowRadius = 0.5f;
        withScale(0.85f);
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }
}
