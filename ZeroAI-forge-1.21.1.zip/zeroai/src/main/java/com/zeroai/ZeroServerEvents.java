package com.zeroai;

import com.zeroai.entity.ZeroEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ZeroMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ZeroServerEvents {
    private static boolean isZero(Entity e) {
        return e instanceof ZeroEntity || (e != null && e.getTags().contains("zero_minion"));
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !ZeroCommonConfig.BACKROOMS_ENABLED.get()) return;
        Entity src = e.getSource().getEntity();
        if (!isZero(src) && !isZero(e.getSource().getDirectEntity())) return;
        if (BackroomsManager.send(p, src)) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) BackroomsManager.tick(e.getServer());
    }
}
