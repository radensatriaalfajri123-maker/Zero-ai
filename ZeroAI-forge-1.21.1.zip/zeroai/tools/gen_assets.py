#!/usr/bin/env python3
"""Generator aset Zero AI: model geo (GeckoLib), texture 2048px + glow map, dan animasi.
Jalankan: python3 tools/gen_assets.py src/main/resources/assets/zeroai"""
import json, math, os, random, sys
import numpy as np
from PIL import Image, ImageDraw

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
S = 24          # piksel per 1 unit model (1/16 blok) -> sangat detail
TEX = 2048

# ------------------------------------------------------------------ MODEL
BONES = [  # name, parent, pivot
    ("root", None, (0, 0, 0)), ("body", "root", (0, 10, 0)), ("torso", "body", (0, 11, 0)),
    ("head", "torso", (0, 21.5, 0)), ("antenna", "head", (0, 29.8, 0)),
    ("eye_r", "head", (1.9, 24.9, -4.7)), ("eye_l", "head", (-1.9, 24.9, -4.7)),
    ("chest_core", "torso", (0, 16, -3.15)), ("backpack", "torso", (0, 15.5, 4.5)),
    ("right_arm", "torso", (6.8, 19, 0)), ("right_forearm", "right_arm", (7.1, 12.5, 0)), ("right_hand", "right_forearm", (7.1, 6, 0)),
    ("left_arm", "torso", (-6.8, 19, 0)), ("left_forearm", "left_arm", (-7.1, 12.5, 0)), ("left_hand", "left_forearm", (-7.1, 6, 0)),
    ("right_leg", "body", (2.6, 8.5, 0)), ("right_shin", "right_leg", (2.6, 4.2, 0)), ("right_foot", "right_shin", (2.6, 0.8, 0)),
    ("left_leg", "body", (-2.6, 8.5, 0)), ("left_shin", "left_leg", (-2.6, 4.2, 0)), ("left_foot", "left_shin", (-2.6, 0.8, 0)),
]
def C(bone, name, o, s, mat): return dict(bone=bone, name=name, o=o, s=s, mat=mat)
def mir(c):
    n = c["name"].replace("r", "l", 1) if False else c["name"] + "_L"
    b = c["bone"].replace("right", "left")
    o = (-(c["o"][0] + c["s"][0]), c["o"][1], c["o"][2])
    return dict(bone=b, name=n, o=o, s=c["s"], mat=c["mat"])

CUBES = [
    C("body", "pelvis", (-4, 8, -2.5), (8, 3, 5), "plate"),
    C("torso", "abdomen", (-3.2, 10.6, -2), (6.4, 1.2, 4), "dark"),
    C("torso", "chest", (-5, 11.5, -3), (10, 8.5, 6), "plate"),
    C("chest_core", "core", (-1.6, 14.4, -3.35), (3.2, 3.2, 0.4), "glow"),
    C("torso", "neck", (-1.5, 20, -1.5), (3, 1.6, 3), "dark"),
    C("backpack", "pack", (-3.6, 12, 3), (7.2, 7, 3), "plate"),
    C("backpack", "vent1", (-2.6, 17, 5.95), (5.2, 0.6, 0.15), "glow"),
    C("backpack", "vent2", (-2.6, 15.6, 5.95), (5.2, 0.6, 0.15), "glow"),
    C("backpack", "vent3", (-2.6, 14.2, 5.95), (5.2, 0.6, 0.15), "glow"),
    C("head", "skull", (-4.5, 21.5, -4), (9, 7.5, 8), "plate"),
    C("head", "visor", (-3.7, 22.6, -4.45), (7.4, 4.4, 0.45), "screen"),
    C("eye_r", "eyer", (0.9, 24.0, -4.9), (2, 1.8, 0.45), "eye"),
    C("eye_l", "eyel", (-2.9, 24.0, -4.9), (2, 1.8, 0.45), "eye"),
    C("head", "earr", (4.5, 23, -1.5), (1.3, 4, 3), "plate"),
    C("head", "earl", (-5.8, 23, -1.5), (1.3, 4, 3), "plate"),
    C("head", "lightr", (5.8, 24, -0.6), (0.15, 2, 1.2), "glow"),
    C("head", "lightl", (-5.95, 24, -0.6), (0.15, 2, 1.2), "glow"),
    C("head", "cap", (-3, 29, -3), (6, 0.8, 6), "dark"),
    C("antenna", "rod", (-0.4, 29.8, -0.4), (0.8, 3.8, 0.8), "dark"),
    C("antenna", "ball", (-1.2, 33.6, -1.2), (2.4, 2.4, 2.4), "glow"),
]
RIGHT = [
    C("right_arm", "pad", (5.2, 17.8, -2.4), (4, 3, 4.8), "plate"),
    C("right_arm", "uarm", (5.7, 12.8, -1.5), (2.8, 5.2, 3), "plate"),
    C("right_forearm", "elbow", (5.8, 11.9, -1.3), (2.6, 1.3, 2.6), "dark"),
    C("right_forearm", "farm", (5.9, 6.2, -1.5), (2.4, 5.8, 3), "plate"),
    C("right_hand", "palm", (5.9, 3.6, -1.3), (2.4, 2.6, 2.6), "dark"),
    C("right_hand", "claw1", (5.8, 1.8, -1.4), (0.8, 1.9, 0.8), "plate"),
    C("right_hand", "claw2", (5.8, 1.8, 0.6), (0.8, 1.9, 0.8), "plate"),
    C("right_hand", "claw3", (7.3, 1.8, -0.4), (0.8, 1.9, 0.8), "plate"),
    C("right_leg", "hip", (1.2, 8.3, -1.6), (2.8, 0.9, 3.2), "dark"),
    C("right_leg", "thigh", (1.0, 4.6, -1.9), (3.2, 3.9, 3.8), "plate"),
    C("right_shin", "knee", (1.4, 3.8, -1.5), (2.4, 1, 3), "dark"),
    C("right_shin", "shin", (1.2, 1.0, -1.7), (2.8, 3.0, 3.4), "plate"),
    C("right_foot", "foot", (0.9, 0.4, -3.4), (3.4, 1.0, 5.6), "plate"),
    C("right_foot", "sole", (0.8, 0, -3.5), (3.6, 0.4, 5.8), "dark"),
]
for c in RIGHT: CUBES.append(c)
for c in RIGHT: CUBES.append(mir(c))
FACES = ["north", "south", "east", "west", "up", "down"]
def face_size(c, f):
    w, h, d = c["s"]
    return {"north": (w, h), "south": (w, h), "east": (d, h), "west": (d, h), "up": (w, d), "down": (w, d)}[f]

# ------------------------------------------------------------------ PACK ATLAS
items = []
for ci, c in enumerate(CUBES):
    for f in FACES:
        fw, fh = face_size(c, f)
        items.append((ci, f, max(2, round(fw * S)), max(2, round(fh * S))))
items.sort(key=lambda t: -t[3])
PAD = 2
pos = {}; x = y = rowh = 0
for ci, f, w, h in items:
    if x + w + PAD > TEX: x = 0; y += rowh + PAD; rowh = 0
    pos[(ci, f)] = (x, y, w, h); x += w + PAD; rowh = max(rowh, h)
assert y + rowh <= TEX, f"atlas penuh: {y+rowh}"
print("atlas terpakai:", y + rowh, "/", TEX)

# ------------------------------------------------------------------ PAINT
def noise(h, w, scale, seed):
    rng = np.random.default_rng(seed)
    n = rng.random((max(2, h // scale + 2), max(2, w // scale + 2)))
    im = Image.fromarray((n * 255).astype(np.uint8)).resize((w, h), Image.BICUBIC)
    return np.asarray(im, np.float32) / 255.0
def fbm(h, w, seed):
    return 0.5 * noise(h, w, 40, seed) + 0.3 * noise(h, w, 9, seed + 1) + 0.2 * noise(h, w, 2, seed + 2)
def tint(c, k): return tuple(int(max(0, min(255, v * k))) for v in c)
def lighter(c, a): return tuple(min(255, v + a) for v in c)

def bolt(dr, bx, by, r, sk):
    dr.ellipse([bx - r - 1, by - r - 1, bx + r + 1, by + r + 1], fill=(0, 0, 0, 120))
    dr.ellipse([bx - r, by - r, bx + r, by + r], fill=tint(sk["plate"], 0.55) + (255,))
    dr.ellipse([bx - r + 1, by - r + 1, bx + r - 1, by + r - 1], fill=tint(sk["plate"], 0.85) + (255,))
    dr.ellipse([bx - r // 2 - 1, by - r // 2 - 1, bx - r // 2 + 1, by - r // 2 + 1], fill=(255, 255, 255, 200))
    dr.line([bx - r + 2, by + 1, bx + r - 2, by - 1], fill=(20, 20, 20, 200), width=1)

def plate(w, h, seed, sk, face):
    rng = random.Random(seed)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    base = np.array(sk["plate"], np.float32)
    streak = np.asarray(Image.fromarray((np.random.default_rng(seed + 5).random((h, 1)) * 255).astype(np.uint8)).resize((w, h)), np.float32) / 255
    lum = (1.10 - 0.22 * yy / max(1, h - 1)) * (0.92 + 0.12 * fbm(h, w, seed) + 0.035 * streak)
    col = base[None, None, :] * lum[..., None]
    d = np.minimum(np.minimum(xx, yy), np.minimum(w - 1 - xx, h - 1 - yy))
    b = max(3, int(min(w, h) * 0.05))
    bev = np.clip(1 - d / b, 0, 1)
    hi = ((xx < b) | (yy < b)).astype(np.float32); lo = ((xx >= w - b) | (yy >= h - b)).astype(np.float32)
    col += (bev * hi)[..., None] * 42 - (bev * lo)[..., None] * 55
    ao = np.clip(1 - d / (min(w, h) * 0.14), 0, 1) * 0.14
    col *= (1 - ao)[..., None]
    im = Image.fromarray(np.clip(col, 0, 255).astype(np.uint8), "RGB")
    dr = ImageDraw.Draw(im, "RGBA")
    gl = Image.new("RGBA", (w, h), (0, 0, 0, 0)); gd = ImageDraw.Draw(gl)
    m = int(min(w, h) * 0.13); lw = max(1, int(min(w, h) * 0.014))
    if min(w, h) >= 40:
        dr.rectangle([m, m, w - 1 - m, h - 1 - m], outline=sk["line"] + (210,), width=lw)
        dr.rectangle([m + lw, m + lw, w - 1 - m - lw, h - 1 - m - lw], outline=(255, 255, 255, 46), width=1)
        dr.rectangle([m + lw + 1, m + lw + 1, w - 2 - m - lw, h - 2 - m - lw], fill=(0, 0, 0, 16))
        r = max(3, int(min(w, h) * 0.034))
        for bx, by in [(m // 2, m // 2), (w - 1 - m // 2, m // 2), (m // 2, h - 1 - m // 2), (w - 1 - m // 2, h - 1 - m // 2)]:
            bolt(dr, bx, by, r, sk)
        if w >= 96:
            xs = w // 2
            dr.line([xs, m, xs, h - m], fill=sk["line"] + (180,), width=2); dr.line([xs + 2, m, xs + 2, h - m], fill=(255, 255, 255, 50), width=1)
        if rng.random() < 0.8 and w >= 48 and h >= 44:
            ys = int(h * rng.uniform(0.62, 0.78)); t = max(4, int(h * 0.05)); x0, x1 = m + 5, w - m - 5
            dr.rectangle([x0 - 1, ys - 1, x1 + 1, ys + t + 1], fill=(0, 0, 0, 110))
            dr.rectangle([x0, ys, x1, ys + t], fill=sk["accent"] + (255,))
            dr.rectangle([x0, ys, x1, ys + max(1, t // 3)], fill=lighter(sk["accent"], 80) + (255,))
            gd.rectangle([x0, ys, x1, ys + t], fill=sk["accent"] + (255,))
        for _ in range(rng.randint(1, 4)):  # kotak kecil / label teknis
            sw, sh = rng.randint(m, m * 3), max(3, m // 3)
            sx, sy = rng.randint(m + 4, max(m + 5, w - m - sw - 4)), rng.randint(m + 4, max(m + 5, int(h * 0.5)))
            dr.rectangle([sx, sy, sx + sw, sy + sh], fill=(0, 0, 0, 60), outline=sk["line"] + (140,))
            for k in range(0, sw - 4, 6): dr.line([sx + 3 + k, sy + 2, sx + 3 + k, sy + sh - 2], fill=(255, 255, 255, 60))
    for _ in range(max(3, w * h // 9000)):  # goresan
        x0, y0 = rng.randint(0, w - 1), rng.randint(0, h - 1)
        x1, y1 = x0 + rng.randint(-w // 5, w // 5), y0 + rng.randint(-h // 8, h // 8)
        dr.line([x0, y0, x1, y1], fill=(255, 255, 255, rng.randint(22, 55)) if rng.random() < .6 else (0, 0, 0, rng.randint(30, 70)), width=1)
    return im.convert("RGBA"), gl

def dark(w, h, seed, sk, face):
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    rib = 0.5 + 0.5 * np.sin(yy * 2 * np.pi / (S * 0.42))
    lum = 0.78 + 0.30 * rib + 0.10 * fbm(h, w, seed)
    col = np.array(sk["dark"], np.float32)[None, None, :] * lum[..., None]
    d = np.minimum(np.minimum(xx, yy), np.minimum(w - 1 - xx, h - 1 - yy))
    col += (np.clip(1 - d / 3, 0, 1) * 18)[..., None]
    im = Image.fromarray(np.clip(col, 0, 255).astype(np.uint8), "RGB").convert("RGBA")
    return im, Image.new("RGBA", (w, h), (0, 0, 0, 0))

def glow(w, h, seed, sk, face):
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    r = np.clip(np.sqrt(((xx - w / 2) / (w / 2)) ** 2 + ((yy - h / 2) / (h / 2)) ** 2), 0, 1)
    core = np.array(sk["glow_core"], np.float32); edge = np.array(sk["glow"], np.float32)
    t = (r ** 1.6)[..., None]
    col = core * (1 - t) + edge * t
    col *= (0.92 + 0.08 * np.sin(yy * 0.9))[..., None]
    im = Image.fromarray(np.clip(col, 0, 255).astype(np.uint8), "RGB").convert("RGBA")
    return im, im.copy()

def screen(w, h, seed, sk, face):
    if face != "north": return dark(w, h, seed, sk, face)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    col = np.zeros((h, w, 3), np.float32); col[...] = np.array(sk["glass"], np.float32)
    col *= (1.0 - 0.5 * yy / h)[..., None]
    col *= (0.82 + 0.18 * ((yy.astype(int) % 4) < 2))[..., None]          # scanline
    col += (((xx.astype(int) % 24) == 0) | ((yy.astype(int) % 24) == 0))[..., None] * np.array(sk["glow"], np.float32) * 0.08  # grid
    refl = np.clip(1 - np.abs((xx - yy * 1.3) - w * 0.25) / (w * 0.12), 0, 1) * 22
    col += refl[..., None]
    d = np.minimum(np.minimum(xx, yy), np.minimum(w - 1 - xx, h - 1 - yy))
    col *= (0.55 + 0.45 * np.clip(d / 6, 0, 1))[..., None]
    im = Image.fromarray(np.clip(col, 0, 255).astype(np.uint8), "RGB").convert("RGBA")
    return im, Image.new("RGBA", (w, h), (0, 0, 0, 0))

def eye(w, h, seed, sk, face):
    if face != "north": return glow(w, h, seed, sk, face)
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
    if sk["angry"]:
        dr.polygon([(0, int(h * .15)), (w - 1, int(h * .55)), (w - 1, h - 1), (0, int(h * .85))], fill=sk["glow"] + (255,))
        dr.polygon([(int(w * .2), int(h * .35)), (int(w * .85), int(h * .62)), (int(w * .85), int(h * .8)), (int(w * .2), int(h * .72))], fill=sk["glow_core"] + (255,))
        dr.rectangle([int(w * .45), int(h * .3), int(w * .55), int(h * .85)], fill=(20, 0, 0, 255))
    else:
        dr.rounded_rectangle([0, 0, w - 1, h - 1], radius=h // 3, fill=sk["glow"] + (255,))
        dr.rounded_rectangle([w // 8, h // 8, w - 1 - w // 8, h - 1 - h // 5], radius=h // 4, fill=sk["glow_core"] + (255,))
        dr.ellipse([w // 5, h // 6, w // 5 + w // 5, h // 6 + h // 4], fill=(255, 255, 255, 255))
    rgb = Image.new("RGBA", (w, h), (0, 0, 0, 255)); rgb.alpha_composite(im)
    return rgb, im.copy()

PAINT = {"plate": plate, "dark": dark, "glow": glow, "screen": screen, "eye": eye}
SKINS = {
    "zero": dict(plate=(206, 214, 224), line=(70, 82, 98), accent=(0, 190, 255), dark=(40, 45, 56), glow=(30, 215, 255),
                 glow_core=(215, 255, 255), glass=(8, 18, 28), angry=False),
    "zero_monster": dict(plate=(84, 30, 34), line=(20, 6, 8), accent=(255, 40, 28), dark=(18, 12, 14), glow=(255, 36, 20),
                         glow_core=(255, 200, 120), glass=(20, 4, 4), angry=True),
}

def build_texture(name, sk):
    atlas = Image.new("RGBA", (TEX, TEX), sk["dark"] + (255,))
    gatlas = Image.new("RGBA", (TEX, TEX), (0, 0, 0, 0))
    for (ci, f), (x, y, w, h) in pos.items():
        c = CUBES[ci]
        im, gl = PAINT[c["mat"]](w, h, hash((c["name"], c["bone"], f)) & 0xFFFF, sk, f)
        atlas.paste(im, (x, y)); gatlas.paste(gl, (x, y))
    d = os.path.join(OUT, "textures", "entity"); os.makedirs(d, exist_ok=True)
    atlas.convert("RGB").save(os.path.join(d, name + ".png"), optimize=True)
    gatlas.save(os.path.join(d, name + "_glowing.png"), optimize=True)
    print("tulis", name)

for n, sk in SKINS.items(): build_texture(n, sk)

# ------------------------------------------------------------------ GEO JSON
bones = []
for bn, parent, pv in BONES:
    b = {"name": bn, "pivot": list(pv)}
    if parent: b["parent"] = parent
    cubes = []
    for ci, c in enumerate(CUBES):
        if c["bone"] != bn: continue
        uv = {f: {"uv": [pos[(ci, f)][0], pos[(ci, f)][1]], "uv_size": [pos[(ci, f)][2], pos[(ci, f)][3]]} for f in FACES}
        cubes.append({"origin": list(c["o"]), "size": list(c["s"]), "uv": uv})
    if cubes: b["cubes"] = cubes
    bones.append(b)
geo = {"format_version": "1.12.0", "minecraft:geometry": [{"description": {
    "identifier": "geometry.zero", "texture_width": TEX, "texture_height": TEX,
    "visible_bounds_width": 6, "visible_bounds_height": 6, "visible_bounds_offset": [0, 1.5, 0]}, "bones": bones}]}
os.makedirs(os.path.join(OUT, "geo"), exist_ok=True)
json.dump(geo, open(os.path.join(OUT, "geo", "zero.geo.json"), "w"), separators=(",", ":"))

# ------------------------------------------------------------------ ANIMASI
sin, cos, pi = math.sin, math.cos, math.pi
ANIMS = {}
def ease(x): x = max(0, min(1, x)); return x * x * (3 - 2 * x)
def bump(t, c, wd): return max(0.0, 1 - abs(t - c) / wd)
def sc(v): return [v, v, v]
def merge(*ds):
    out = {}
    for d in ds:
        for b, chs in d.items(): out.setdefault(b, {}).update(chs)
    return out
def anim(name, length, loop, fn, fps=20):
    n = int(round(length * fps)); bones = {}
    for i in range(n + 1):
        t = min(length, i / fps)
        for b, chs in fn(t).items():
            for ch, v in chs.items():
                bones.setdefault(b, {}).setdefault(ch, {})[f"{t:.2f}"] = [round(x, 3) for x in v]
    ANIMS["animation.zero." + name] = {"loop": loop, "animation_length": length, "bones": bones}
def eyes(sx=1, sy=1): return {"eye_l": {"scale": [sx, sy, 1]}, "eye_r": {"scale": [sx, sy, 1]}}
def mon(): return {"root": {"scale": sc(1.4)}}

def idle(t):
    u = 2 * pi * t / 8
    bl = 1 - 0.92 * (bump(t, 1.5, .12) + bump(t, 4.7, .12) + bump(t, 6.3, .12))
    s = 1 + 0.09 * sin(4 * u)
    return merge({"body": {"position": [0, sin(2 * u) * .12, 0]}, "torso": {"rotation": [sin(2 * u) * 1.2, sin(u) * 2, 0]},
        "head": {"rotation": [sin(2 * u + 1) * 1.8, sin(u) * 9, sin(2 * u) * 1.5]},
        "antenna": {"rotation": [sin(4 * u) * 5, 0, sin(4 * u + 1) * 8]}, "chest_core": {"scale": sc(s)},
        "right_arm": {"rotation": [sin(2 * u) * 3, 0, -4 + sin(2 * u) * 1.5]}, "left_arm": {"rotation": [-sin(2 * u) * 3, 0, 4 - sin(2 * u) * 1.5]},
        "right_forearm": {"rotation": [-10, 0, 0]}, "left_forearm": {"rotation": [-10, 0, 0]}}, eyes(1, bl))
anim("idle", 8, True, idle)

def walk(t):
    u = 2 * pi * t
    return merge({"body": {"position": [0, abs(sin(u)) * .55, 0]}, "torso": {"rotation": [3, 5 * sin(u), 0]},
        "head": {"rotation": [-2, -4 * sin(u), 0]}, "antenna": {"rotation": [0, 0, 10 * sin(u - .8)]},
        "right_leg": {"rotation": [30 * sin(u), 0, 0]}, "left_leg": {"rotation": [-30 * sin(u), 0, 0]},
        "right_shin": {"rotation": [42 * max(0, sin(u - 1.3)), 0, 0]}, "left_shin": {"rotation": [42 * max(0, -sin(u - 1.3)), 0, 0]},
        "right_foot": {"rotation": [-12 * max(0, sin(u - 1.3)), 0, 0]}, "left_foot": {"rotation": [-12 * max(0, -sin(u - 1.3)), 0, 0]},
        "right_arm": {"rotation": [-30 * sin(u), 0, -4]}, "left_arm": {"rotation": [30 * sin(u), 0, 4]},
        "right_forearm": {"rotation": [-22, 0, 0]}, "left_forearm": {"rotation": [-22, 0, 0]}, "chest_core": {"scale": sc(1 + .06 * sin(2 * u))}})
anim("walk", 1.0, True, walk)

def run(t):
    u = 2 * pi * t / 0.6
    return merge(mon(), {"body": {"position": [0, abs(sin(u)) * .8 - .3, 0]}, "torso": {"rotation": [16, 8 * sin(u), 0]},
        "head": {"rotation": [14, -6 * sin(u), 4 * sin(2 * u)]}, "antenna": {"rotation": [0, 0, 22 * sin(2 * u)]},
        "right_leg": {"rotation": [44 * sin(u), 0, 0]}, "left_leg": {"rotation": [-44 * sin(u), 0, 0]},
        "right_shin": {"rotation": [55 * max(0, sin(u - 1.3)), 0, 0]}, "left_shin": {"rotation": [55 * max(0, -sin(u - 1.3)), 0, 0]},
        "right_arm": {"rotation": [-70 + 30 * sin(u), 0, -18]}, "left_arm": {"rotation": [-70 - 30 * sin(u), 0, 18]},
        "right_forearm": {"rotation": [-40, 0, 0]}, "left_forearm": {"rotation": [-40, 0, 0]},
        "chest_core": {"scale": sc(1.3 + .25 * sin(2 * u))}}, eyes(1.25, .55))
anim("run", 0.6, True, run)

def monster_idle(t):
    u = 2 * pi * t / 1.2
    return merge(mon(), {"body": {"position": [sin(8 * u) * .15, -.5 + sin(u) * .2, 0]},
        "torso": {"rotation": [14 + sin(u) * 3, sin(u) * 6, 0]}, "head": {"rotation": [12, sin(2 * u) * 8, sin(6 * u) * 4]},
        "antenna": {"rotation": [sin(3 * u) * 14, 0, sin(5 * u) * 28]},
        "right_arm": {"rotation": [-62 + sin(3 * u) * 8, 0, -26 + sin(5 * u) * 6]}, "left_arm": {"rotation": [-62 - sin(3 * u) * 8, 0, 26 - sin(5 * u) * 6]},
        "right_forearm": {"rotation": [-40 + sin(4 * u) * 8, 0, 0]}, "left_forearm": {"rotation": [-40 - sin(4 * u) * 8, 0, 0]},
        "right_leg": {"rotation": [-8, 0, -6]}, "left_leg": {"rotation": [-8, 0, 6]},
        "chest_core": {"scale": sc(1.35 + .3 * abs(sin(2 * u)))}}, eyes(1.3, .5))
anim("monster_idle", 1.2, True, monster_idle)

def attack(t):
    wind = ease(t / 0.18); strike = ease((t - 0.18) / 0.1); back = ease((t - 0.3) / 0.3)
    r = -30 - 100 * wind + 160 * strike - 30 * back * 0
    r = (-30 - 100 * wind) if t < 0.18 else (-130 + 170 * strike) if t < 0.3 else (40 - 70 * back)
    return merge(mon(), {"right_arm": {"rotation": [r, 0, -20]}, "right_forearm": {"rotation": [-30 + 20 * strike, 0, 0]},
        "torso": {"rotation": [14 + 8 * strike, -22 * wind + 44 * strike - 22 * back, 0]},
        "head": {"rotation": [12 + 10 * strike, 0, 0]}, "left_arm": {"rotation": [-62, 0, 26]}, "chest_core": {"scale": sc(1.6)}}, eyes(1.3, .45))
anim("attack", 0.6, False, attack)

def wave(t):
    u = 2 * pi * t / 2
    return merge(idle(t * 0 + 1.0), {"right_arm": {"rotation": [-20, 0, -150 + 0 * u]}, "right_forearm": {"rotation": [0, 0, 28 * sin(4 * u)]},
        "head": {"rotation": [0, 0, 8 * sin(u)]}, "antenna": {"rotation": [0, 0, 16 * sin(4 * u)]}, "torso": {"rotation": [0, 6 * sin(u), 0]}}, eyes(1.1, .55 + .45 * (1 if bump(t % 1, .5, .2) < .5 else .6)))
anim("wave", 2, True, wave)

def talk(t):
    u = 2 * pi * t / 1.6
    return merge(idle(1.0), {"head": {"rotation": [3 * sin(3 * u), 5 * sin(u), 3 * sin(2 * u)]}, "antenna": {"rotation": [0, 0, 14 * sin(3 * u)]},
        "right_arm": {"rotation": [-30 + 22 * sin(u + 1), 0, -14]}, "left_arm": {"rotation": [-18 + 16 * sin(u + 3), 0, 14]},
        "right_forearm": {"rotation": [-34 + 12 * sin(2 * u), 0, 0]}, "left_forearm": {"rotation": [-28 + 10 * sin(2 * u + 1), 0, 0]},
        "torso": {"rotation": [2 * sin(3 * u), 3 * sin(u), 0]}, "chest_core": {"scale": sc(1.1 + .25 * abs(sin(4 * u)))}}, eyes(1.05, 1 + .08 * sin(3 * u)))
anim("talk", 1.6, True, talk)

def think(t):
    u = 2 * pi * t / 3
    return merge(idle(1.0), {"right_arm": {"rotation": [-112, 0, -6]}, "right_forearm": {"rotation": [-100, 0, 0]},
        "head": {"rotation": [9, 8 * sin(u), 9]}, "antenna": {"rotation": [0, 360 * t / 3 % 360 if False else 0, 18 * sin(2 * u)]},
        "torso": {"rotation": [4, -4, 0]}, "chest_core": {"scale": sc(1 + .3 * abs(sin(6 * u)))}},
        {"eye_l": {"scale": [1, .55, 1]}, "eye_r": {"scale": [1, 1.0, 1]}})
anim("think", 3, True, think)

def listen(t):
    u = 2 * pi * t / 2
    return merge(idle(1.0), {"head": {"rotation": [-4, 0, 12 + 2 * sin(u)]}, "antenna": {"rotation": [-10, 0, 10 * sin(2 * u)], "scale": [1, 1.35, 1]},
        "torso": {"rotation": [5, 0, 0]}, "right_arm": {"rotation": [-70, 0, -30]}, "right_forearm": {"rotation": [-92, 0, 0]},
        "chest_core": {"scale": sc(1.15 + .15 * sin(4 * u))}}, eyes(1.2, 1.2))
anim("listen", 2, True, listen)

def dance(t):
    u = 2 * pi * t / 2
    return merge({"body": {"position": [sin(u) * 1.2, abs(sin(2 * u)) * 1.4 - .3, 0], "rotation": [0, sin(u) * 14, 0]},
        "torso": {"rotation": [4 * sin(2 * u), 22 * sin(u), 5 * sin(u)]}, "head": {"rotation": [6 * sin(4 * u), -26 * sin(u), 10 * sin(2 * u)]},
        "antenna": {"rotation": [0, 0, 26 * sin(4 * u)]},
        "right_arm": {"rotation": [-130 + 35 * sin(2 * u), 0, -20]}, "left_arm": {"rotation": [-130 - 35 * sin(2 * u), 0, 20]},
        "right_forearm": {"rotation": [-30 + 25 * sin(4 * u), 0, 0]}, "left_forearm": {"rotation": [-30 - 25 * sin(4 * u), 0, 0]},
        "right_leg": {"rotation": [12 * sin(2 * u) - 6, 0, -4]}, "left_leg": {"rotation": [-12 * sin(2 * u) - 6, 0, 4]},
        "right_shin": {"rotation": [20 * max(0, sin(2 * u)), 0, 0]}, "left_shin": {"rotation": [20 * max(0, -sin(2 * u)), 0, 0]},
        "chest_core": {"scale": sc(1.1 + .4 * abs(sin(2 * u)))}}, eyes(1.15, .5 + .5 * abs(sin(2 * u))))
anim("dance", 2, True, dance)

def happy(t):
    u = 2 * pi * t / 1.4
    j = max(0, sin(u)) 
    return merge({"body": {"position": [0, j * 2.6, 0]}, "torso": {"rotation": [-3, 6 * sin(u), 0]}, "head": {"rotation": [-6, 0, 6 * sin(2 * u)]},
        "antenna": {"rotation": [0, 0, 28 * sin(4 * u)]}, "right_arm": {"rotation": [-165 + 14 * sin(2 * u), 0, -14]}, "left_arm": {"rotation": [-165 - 14 * sin(2 * u), 0, 14]},
        "right_forearm": {"rotation": [-14, 0, 0]}, "left_forearm": {"rotation": [-14, 0, 0]},
        "right_leg": {"rotation": [-14 * j, 0, 0]}, "left_leg": {"rotation": [-14 * j, 0, 0]}, "right_shin": {"rotation": [30 * j, 0, 0]}, "left_shin": {"rotation": [30 * j, 0, 0]},
        "chest_core": {"scale": sc(1.3 + .2 * sin(4 * u))}}, eyes(1.25, .38))
anim("happy", 1.4, True, happy)

def sad(t):
    u = 2 * pi * t / 3
    return merge({"body": {"position": [0, -.6 + sin(u) * .1, 0]}, "torso": {"rotation": [10, 0, 0]}, "head": {"rotation": [26 + sin(u) * 2, sin(u) * 6, 4]},
        "antenna": {"rotation": [30, 0, 38]}, "right_arm": {"rotation": [8, 0, -10]}, "left_arm": {"rotation": [8, 0, 10]},
        "right_forearm": {"rotation": [-4, 0, 0]}, "left_forearm": {"rotation": [-4, 0, 0]},
        "chest_core": {"scale": sc(.7 + .06 * sin(2 * u))}}, eyes(.9, .45 + .05 * sin(2 * u)))
anim("sad", 3, True, sad)

def scan(t):
    u = 2 * pi * t / 3
    return merge(idle(1.0), {"head": {"rotation": [2, 58 * sin(u), 0]}, "torso": {"rotation": [0, 12 * sin(u), 0]},
        "antenna": {"rotation": [0, 0, 20 * sin(3 * u)]}, "right_arm": {"rotation": [-34, 0, -8]}, "right_forearm": {"rotation": [-60, 0, 0]},
        "chest_core": {"scale": sc(1 + .35 * abs(sin(3 * u)))}}, eyes(1.3, .7))
anim("scan", 3, True, scan)

def spawn(t):
    e = ease(t / 0.9); s = e + 0.16 * sin(min(1, t / 0.9) * pi)
    boot = .05 if t < 0.7 else 1 - .9 * (bump(t, .85, .08) + bump(t, 1.0, .06))
    return merge({"root": {"scale": sc(max(.01, s)), "position": [0, -6 * (1 - e), 0]}, "head": {"rotation": [0, 40 * sin(e * 2 * pi) * (1 - e), 0]},
        "antenna": {"rotation": [0, 0, 30 * sin(e * 8 * pi) * (1 - e)]}, "chest_core": {"scale": sc(1 + 1.2 * bump(t, 1.0, .3))},
        "right_arm": {"rotation": [-20 * (1 - e), 0, -30 * (1 - e)]}, "left_arm": {"rotation": [-20 * (1 - e), 0, 30 * (1 - e)]}}, eyes(1, boot))
anim("spawn", 1.6, False, spawn)

def transform(t):
    e = ease(t / 2.0); amp = min(1, t / .4) * (1 - .4 * e); j = sin(t * 60) * amp
    return merge({"root": {"scale": sc(1 + .4 * e), "position": [j * .8, abs(j) * .5, 0]}, "torso": {"rotation": [16 * e + j * 6, j * 10, 0]},
        "head": {"rotation": [12 * e + j * 8, j * 20, j * 12]}, "antenna": {"rotation": [0, 0, j * 60]},
        "right_arm": {"rotation": [-62 * e + j * 18, 0, -26 * e + j * 8]}, "left_arm": {"rotation": [-62 * e - j * 18, 0, 26 * e - j * 8]},
        "chest_core": {"scale": sc(1 + .9 * abs(sin(t * 18)))}}, eyes(1 + .3 * e + .4 * abs(j), 1 - .5 * e + .5 * abs(j)))
anim("transform", 2.0, False, transform)

def death(t):
    e = ease(t / 1.0); fl = 1 - bump(t, .3, .1) * .9 - bump(t, .55, .08) * .9
    return merge({"body": {"position": [0, -2 * e, 0]}, "torso": {"rotation": [38 * e, 0, 0]}, "head": {"rotation": [48 * e, 0, 12 * e]},
        "antenna": {"rotation": [40 * e, 0, 55 * e]}, "right_arm": {"rotation": [20 * e, 0, -22 * e]}, "left_arm": {"rotation": [20 * e, 0, 22 * e]},
        "right_leg": {"rotation": [-30 * e, 0, 0]}, "left_leg": {"rotation": [20 * e, 0, 0]}, "chest_core": {"scale": sc(max(.05, 1 - .95 * e))}},
        eyes(1, max(.05, fl * (1 - e) + .05)))
anim("death", 1.5, "hold_on_last_frame", death)

os.makedirs(os.path.join(OUT, "animations"), exist_ok=True)
json.dump({"format_version": "1.8.0", "animations": ANIMS}, open(os.path.join(OUT, "animations", "zero.animation.json"), "w"), separators=(",", ":"))
print("animasi:", len(ANIMS))
