# Zero AI - Forge 1.21.1

Robot AI pendamping Minecraft. Java 21 + Forge 1.21.1.

## Build
1. Cara termudah: download MDK Forge 1.21.1 dari https://files.minecraftforge.net, lalu salin folder `src/` ke MDK
   (timpa), dan pakai build.gradle MDK-nya. Atau pakai build.gradle di sini (ubah versi Forge jika perlu).
2. `./gradlew build` -> jar ada di `build/libs/`. Taruh di folder `mods/`.

## Pakai
- Tombol **K** : pengaturan (provider, model, API key / server Ollama, bahasa, TTS, command, musik).
  Tombol "Ambil daftar model" lalu "Model >" untuk memilih model otomatis.
- Tahan **G** : bicara (push-to-talk), lepas untuk kirim.
- Ketik di chat: `zero apa itu redstone?` (awalan `zero ` atau `@zero `).
- `/zeroai spawn` atau Spawn Egg "Zero AI" untuk memunculkan robot.
- Beri hadiah (golden apple, diamond, cake, iron, redstone) klik kanan = mood naik. Dipukul = mood turun.
- Mood <= 10 -> MONSTER (menyerang!). Mood >= 40 -> tenang lagi.
- Command AI dijalankan sebagai kamu, jadi butuh OP / cheats aktif.
- Musik: AI bisa memutar robot_dance, happy, sad_beep, space, boss.

## Catatan
- STT: Groq/OpenAI = Whisper, Gemini = audio inline. Ollama tidak punya STT, jadi memakai key Groq/OpenAI jika diisi.
- TTS: sistem (Windows SAPI / macOS Zarvox robot / Linux espeak-ng) atau OpenAI TTS.
- API key tersimpan teks biasa di config/zeroai-client.toml. Jangan bagikan file itu.

## Build jar tanpa install apa-apa (GitHub Actions)
1. Buat repo baru di GitHub, upload seluruh isi folder ini (termasuk `.github`).
2. Buka tab **Actions** -> workflow "Build jar" -> tunggu hijau.
3. Download artifact **zeroai-jar** -> ekstrak -> masukkan jar ke folder `mods/`.

## Build lokal
Install JDK 21 + Gradle 8.8, lalu jalankan `gradle build` di folder ini.

## GeckoLib (wajib)
Mod ini membutuhkan **GeckoLib 4.7.x untuk Forge 1.21.1**. Taruh jar GeckoLib di folder `mods/` bersama jar Zero AI
(download: CurseForge / Modrinth, cari "GeckoLib").

## Animasi
idle, walk, run, monster_idle, attack, spawn, transform, death, wave, talk, think, listen, dance, happy, sad, scan.
Animasi otomatis: mic ditahan = listen, AI berpikir = think, bicara = talk. AI juga bisa memilih emote lewat tag [ANIM].
Aset dibuat ulang dengan: `python3 tools/gen_assets.py src/main/resources/assets/zeroai` (butuh numpy + Pillow).
